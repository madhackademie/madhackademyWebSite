﻿# Chemins LÖVE possibles (winget machine, winget user, install manuelle)
function Get-LoveExecutable {
    param(
        [switch]$PreferConsole
    )

    $lovec = @(
        "${env:ProgramFiles}\LOVE\lovec.exe",
        "${env:ProgramFiles(x86)}\LOVE\lovec.exe",
        (Join-Path $env:LOCALAPPDATA "Programs\LOVE\lovec.exe")
    )
    $love = @(
        "${env:ProgramFiles}\LOVE\love.exe",
        "${env:ProgramFiles(x86)}\LOVE\love.exe",
        (Join-Path $env:LOCALAPPDATA "Programs\LOVE\love.exe")
    )

    if ($PreferConsole) {
        foreach ($p in $lovec) {
            if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
        }
        foreach ($p in $love) {
            if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
        }
    }
    else {
        foreach ($p in $love) {
            if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
        }
        foreach ($p in $lovec) {
            if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
        }
    }

    return $null
}

function Test-LovePresent {
    return [bool](Get-LoveExecutable)
}
