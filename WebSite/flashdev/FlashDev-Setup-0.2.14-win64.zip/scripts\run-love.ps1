# Lance FlashRevisionSoft (Love2D) - lovec.exe si dispo (console updateCheck)
. (Join-Path $PSScriptRoot "resolve-love.ps1")

$GameDir = Join-Path $PSScriptRoot "..\SquelletteGCS" | Resolve-Path

function Start-FlashDevLove {
    param([string]$LovePath)
    Start-Process -FilePath $LovePath -ArgumentList $GameDir.Path -WorkingDirectory $GameDir.Path
}

$LoveExe = Get-LoveExecutable -PreferConsole
if (-not $LoveExe) {
    Write-Host "LOVE introuvable - tentative installation (winget)..." -ForegroundColor Yellow
    $installScript = Join-Path $PSScriptRoot "install-madhackademy.ps1"
    & $installScript -Unattended -SkipVSCode -SkipExtensions -NoDesktopShortcut
    $installExit = if ($null -ne $LASTEXITCODE) { $LASTEXITCODE } else { 0 }
    if ($installExit -ne 0) {
        Write-Error "Installation LOVE echouee (code $installExit). Lancez scripts\install-madhackademy.cmd (App Installer / winget requis)."
        exit 1
    }
    $LoveExe = Get-LoveExecutable -PreferConsole
}

if (-not $LoveExe) {
    Write-Error "Love2D introuvable apres install. Installe LOVE.LOVE via winget ou https://love2d.org puis relance FlashDev.cmd"
    exit 1
}

Start-FlashDevLove -LovePath $LoveExe
