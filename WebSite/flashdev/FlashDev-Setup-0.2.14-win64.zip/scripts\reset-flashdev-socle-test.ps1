﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Desinstalle VS Code + LÖVE et nettoie les dossiers pour retester le socle FlashDev.

.DESCRIPTION
    Pour developpeur / test installeur apres chaque release.
    Ne supprime pas le depot Git FlashRevisionSoft.

.EXAMPLE
    .\scripts\reset-flashdev-socle-test.ps1

.EXAMPLE
    .\scripts\reset-flashdev-socle-test.ps1 -SkipConfirm -AlsoRemoveFlashDevInstall
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$SkipConfirm,
    [switch]$AlsoRemoveFlashDevInstall,
    [switch]$KeepVsCodeProfile,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'

$LoveWingetId = 'Love2d.Love2d'
$VSCodeWingetId = 'Microsoft.VisualStudioCode'

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[!!] $Message" -ForegroundColor Yellow
}

function Stop-SocleProcesses {
    $names = @('Code', 'love', 'LOVE', 'VSCodeUserSetup-x64', 'VSCodeUserSetup', 'CodeSetup')
    foreach ($name in $names) {
        Get-Process -Name $name -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Seconds 1
}

function Invoke-WingetUninstall {
    param(
        [string]$Id,
        [string]$Label
    )

    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Warn "winget absent — desinstall Apps manuelle pour $Label"
        return
    }

    foreach ($scope in @('', 'user', 'machine')) {
        $args = @('uninstall', '--id', $Id, '-e', '--disable-interactivity')
        if ($scope) {
            $args += @('--scope', $scope)
        }
        if ($DryRun) {
            Write-Warn "DryRun : winget uninstall --id $Id$(if ($scope) { " --scope $scope" })"
            continue
        }
        Write-Host "winget uninstall $Label$(if ($scope) { " ($scope)" } else { '' })..."
        $prevEap = $ErrorActionPreference
        $ErrorActionPreference = 'SilentlyContinue'
        try {
            & winget @args 2>&1 | Out-Null
        }
        finally {
            $ErrorActionPreference = $prevEap
        }
    }
}

function Remove-PathIfExists {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }
    if ($DryRun) {
        Write-Warn "DryRun : supprimerait $Path"
        return
    }
    Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $Path) {
        Write-Warn "Impossible de tout supprimer : $Path (fichier ouvert ?)"
    }
    else {
        Write-Ok "Supprime : $Path"
    }
}

function Clear-SocleTempFiles {
    if ($DryRun) {
        Write-Warn 'DryRun : nettoyage TEMP (VSCodeUserSetup, love-*.zip, flashdev-*)'
        return
    }
    Get-ChildItem $env:TEMP -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^(VSCodeUserSetup|love-.*-win64\.zip|flashdev-)' } |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

function Test-SocleAbsent {
    $checks = @(
        "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe",
        "$env:ProgramFiles\LOVE\love.exe",
        "${env:ProgramFiles(x86)}\LOVE\love.exe",
        "$env:LOCALAPPDATA\Programs\LOVE\love.exe"
    )
    Write-Step 'Controle (False = pret pour retest setup)'
    foreach ($p in $checks) {
        $exists = Test-Path -LiteralPath $p
        $status = if ($exists) { 'ENCORE LA' } else { 'absent' }
        $color = if ($exists) { 'Yellow' } else { 'Green' }
        Write-Host "  $status — $p" -ForegroundColor $color
    }
}

Write-Host ''
Write-Host 'FlashDev — reset socle test (VS Code + LOVE)' -ForegroundColor White
Write-Host 'Ne touche pas au depot Git FlashRevisionSoft.' -ForegroundColor DarkGray

if (-not $SkipConfirm -and -not $DryRun) {
    Write-Host ''
    Write-Host 'Desinstalle Visual Studio Code + Love2D et nettoie AppData / Program Files.' -ForegroundColor Yellow
    if ($AlsoRemoveFlashDevInstall) {
        Write-Host 'Inclut : %LOCALAPPDATA%\FlashDev' -ForegroundColor Yellow
    }
    if (-not $KeepVsCodeProfile) {
        Write-Host 'Inclut : %APPDATA%\Code (extensions / reglages VS Code)' -ForegroundColor Yellow
    }
    $answer = Read-Host 'Continuer ? (o/N)'
    if ($answer -notmatch '^[oOyY]') {
        Write-Host 'Annule.'
        exit 0
    }
}

Write-Step 'Arret processus'
if (-not $DryRun) {
    Stop-SocleProcesses
}

Write-Step 'Desinstallation winget'
Invoke-WingetUninstall -Id $VSCodeWingetId -Label 'VS Code'
Invoke-WingetUninstall -Id $LoveWingetId -Label 'LOVE'

Write-Step 'Dossiers residuels'
$paths = @(
    "$env:LOCALAPPDATA\Programs\Microsoft VS Code",
    "$env:ProgramFiles\Microsoft VS Code",
    "${env:ProgramFiles(x86)}\Microsoft VS Code",
    "$env:ProgramFiles\LOVE",
    "${env:ProgramFiles(x86)}\LOVE",
    "$env:LOCALAPPDATA\Programs\LOVE"
)
if (-not $KeepVsCodeProfile) {
    $paths += @(
        "$env:APPDATA\Code",
        "$env:USERPROFILE\.vscode"
    )
}
if ($AlsoRemoveFlashDevInstall) {
    $paths += "$env:LOCALAPPDATA\FlashDev"
}

foreach ($p in $paths) {
    Remove-PathIfExists -Path $p
}

Write-Step 'Fichiers temporaires'
Clear-SocleTempFiles

Test-SocleAbsent

Write-Host ''
if ($DryRun) {
    Write-Warn 'DryRun termine — rien na ete modifie.'
}
else {
    Write-Ok 'Reset termine. Lance FlashDev-Setup-*.exe ou install-madhackademy.ps1 pour retester.'
}
