#Requires -Version 5.1
<#
.SYNOPSIS
    Installe le socle FlashDev : LÖVE 11.x, VS Code, extensions Lua, raccourci Bureau.

.DESCRIPTION
    Cible les eleves / utilisateurs finaux. N installe pas Raylib (deck C++ = etape separee).

.EXAMPLE
    .\scripts\install-madhackademy.ps1

.EXAMPLE
    .\scripts\install-madhackademy.ps1 -DryRun

.EXAMPLE
    .\scripts\install-madhackademy.ps1 -VerifyOnly

.EXAMPLE
    .\scripts\install-madhackademy.ps1 -Interactive
    # Mode pas-a-pas (Entree entre chaque etape) — formation / debug uniquement
#>

[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$VerifyOnly,
    [switch]$SkipLove,
    [switch]$SkipVSCode,
    [switch]$SkipExtensions,
    [switch]$NoDesktopShortcut,
    [switch]$Unattended,
    [switch]$Interactive,
    [string]$LoveExe = "C:\Program Files\LOVE\love.exe",
    [string]$LoveConsoleExe = "C:\Program Files\LOVE\lovec.exe"
)

$ErrorActionPreference = "Stop"

. (Join-Path $PSScriptRoot "resolve-love.ps1")
if (-not $Interactive -and -not $PSBoundParameters.ContainsKey('Unattended')) {
    $Unattended = $true
}
if ($env:FLASHDEV_INSTALL_UNATTENDED -eq '1') {
    $Unattended = $true
}

$scriptDir = Split-Path -Parent $PSCommandPath
$repoRoot = Split-Path -Parent $scriptDir
$gameDir = Join-Path $repoRoot "SquelletteGCS"
$mainLua = Join-Path $gameDir "main.lua"

$LoveWingetId = "Love2d.Love2d"
$LovePortableVersion = "11.5"
$VSCodeWingetId = "Microsoft.VisualStudioCode"
$LuaExtensions = @(
    "sumneko.lua",
    "tomblind.local-lua-debugger-vscode"
)

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
    if ($Interactive -and -not $DryRun -and -not $VerifyOnly) {
        [void](Read-Host "Entree pour continuer")
    }
}

function Test-WingetExitOk {
    param([int]$ExitCode)
    if ($ExitCode -eq 0) {
        return $true
    }
    # Package deja installe / rien a faire (codes winget courants)
    $benign = @(
        -1978335189 # 0x8A150014 — deja installe
    )
    return $benign -contains $ExitCode
}

function Get-VSCodeExtensionCli {
    foreach ($dir in Get-VSCodeBinDirs) {
        $codeCmd = Join-Path $dir "code.cmd"
        if (Test-Path $codeCmd) {
            return $codeCmd
        }
    }
    if (Get-Command code -ErrorAction SilentlyContinue) {
        return (Get-Command code).Source
    }
    return $null
}

function Get-MarketplaceVsixUrl {
    param([string]$ExtensionId)
    $dot = $ExtensionId.IndexOf('.')
    if ($dot -lt 1) {
        throw "ID extension invalide : $ExtensionId"
    }
    $publisher = $ExtensionId.Substring(0, $dot)
    $name = $ExtensionId.Substring($dot + 1)
    return "https://marketplace.visualstudio.com/_apis/public/gallery/publishers/$publisher/vsextensions/$name/latest/vspackage"
}

function Invoke-VSCodeCli {
    param(
        [string[]]$Arguments
    )
    $codeCli = Get-VSCodeExtensionCli
    if (-not $codeCli) {
        throw "CLI VS Code (code.cmd) introuvable"
    }
    if ($Unattended) {
        $proc = Start-Process -FilePath $codeCli -ArgumentList $Arguments -Wait -PassThru -WindowStyle Hidden
        return $proc.ExitCode
    }
    & $codeCli @Arguments
    return $LASTEXITCODE
}

function Get-InstalledVSCodeExtensions {
    $codeCli = Get-VSCodeExtensionCli
    if (-not $codeCli) {
        return @()
    }
    if (-not $Unattended) {
        return @(& $codeCli --list-extensions 2>$null | Where-Object { $_ })
    }

    $outFile = Join-Path $env:TEMP ("flashdev-ext-" + [guid]::NewGuid().ToString('n') + ".txt")
    $errFile = Join-Path $env:TEMP ("flashdev-ext-err-" + [guid]::NewGuid().ToString('n') + ".txt")
    try {
        $null = Start-Process -FilePath $codeCli -ArgumentList @('--list-extensions') -Wait -WindowStyle Hidden `
            -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        if (-not (Test-Path $outFile)) {
            return @()
        }
        return @(Get-Content -LiteralPath $outFile -ErrorAction SilentlyContinue | Where-Object { $_ -match '\S' })
    }
    finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[!!] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "[KO] $Message" -ForegroundColor Red
}

function Test-WingetAvailable {
    return [bool](Get-Command winget -ErrorAction SilentlyContinue)
}

function Get-VSCodeInstallRoots {
    return @(
        (Join-Path $env:LOCALAPPDATA "Programs\Microsoft VS Code"),
        (Join-Path ${env:ProgramFiles} "Microsoft VS Code"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft VS Code")
    ) | Where-Object { $_ -and (Test-Path (Join-Path $_ "Code.exe")) }
}

function Get-VSCodeBinDirs {
    $fromRoots = Get-VSCodeInstallRoots | ForEach-Object { Join-Path $_ "bin" } | Where-Object { Test-Path $_ }
    if ($fromRoots) {
        return @($fromRoots)
    }
    return @(
        (Join-Path $env:LOCALAPPDATA "Programs\Microsoft VS Code\bin"),
        (Join-Path ${env:ProgramFiles} "Microsoft VS Code\bin"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft VS Code\bin")
    ) | Where-Object { $_ -and (Test-Path $_) }
}

function Test-VSCodePresentOnMachine {
    if (Get-VSCodeInstallRoots) {
        return $true
    }
    foreach ($dir in Get-VSCodeBinDirs) {
        if (Test-Path (Join-Path $dir "code.cmd")) {
            return $true
        }
    }
    return $false
}

function Test-LoveInstalled {
    return Test-LovePresent
}

function Test-VSCodeInstalled {
    if (Get-Command code -ErrorAction SilentlyContinue) {
        return $true
    }
    foreach ($dir in Get-VSCodeBinDirs) {
        if (Test-Path (Join-Path $dir "code.cmd")) {
            return $true
        }
    }
    return $false
}

function Stop-VSCodeProcessesForInstall {
    if ($DryRun -or $VerifyOnly) {
        return
    }
    $names = @('Code', 'VSCodeUserSetup-x64', 'VSCodeUserSetup', 'CodeSetup')
    foreach ($name in $names) {
        Get-Process -Name $name -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Seconds 2
}

$VSCodeUserSetupUrl = 'https://update.code.visualstudio.com/latest/win32-x64-user'
$VSCodeInnoSilentArgs = @('/VERYSILENT', '/NORESTART', '/MERGETASKS=addtopath,runcode!')

function Install-VSCodeDirectSilent {
    if (Test-VSCodePresentOnMachine) {
        return
    }

    if ($DryRun) {
        Write-Warn "DryRun : telechargerait VS Code user setup + Inno /VERYSILENT"
        return
    }

    Stop-VSCodeProcessesForInstall

    $setupPath = Join-Path $env:TEMP ('VSCodeUserSetup-x64-flashdev-' + [guid]::NewGuid().ToString('n') + '.exe')
    Write-Host "Telechargement VS Code (installateur utilisateur, silencieux)..."
    try {
        Invoke-WebRequest -Uri $VSCodeUserSetupUrl -OutFile $setupPath -UseBasicParsing
    }
    catch {
        Remove-Item -LiteralPath $setupPath -Force -ErrorAction SilentlyContinue
        throw "Telechargement VS Code echoue : $($_.Exception.Message)"
    }

    Write-Host "Installation VS Code en cours (1-3 min, sans fenetre)..."
    $proc = Start-Process -FilePath $setupPath -ArgumentList $VSCodeInnoSilentArgs -Wait -PassThru -WindowStyle Hidden
    Remove-Item -LiteralPath $setupPath -Force -ErrorAction SilentlyContinue

    if ($proc.ExitCode -ne 0 -and -not (Test-VSCodePresentOnMachine)) {
        throw "Installateur VS Code code $($proc.ExitCode)"
    }
    if (Test-VSCodePresentOnMachine) {
        Write-Ok "VS Code installe"
    }
}

function Install-VSCodeForFlashDev {
    if (Test-VSCodePresentOnMachine) {
        return
    }

    # winget --silent sur VS Code bloque souvent (installateur Inno en attente) : setup direct d abord
    try {
        Install-VSCodeDirectSilent
    }
    catch {
        Write-Warn "Setup direct VS Code : $($_.Exception.Message)"
    }

    if (Test-VSCodePresentOnMachine) {
        return
    }

    if (-not (Test-WingetAvailable)) {
        throw "VS Code introuvable. Installe-le depuis https://code.visualstudio.com ou relance le setup FlashDev."
    }

    Stop-VSCodeProcessesForInstall
    Write-Host "Nouvelle tentative VS Code via winget (override silencieux)..."
    $wingetArgs = @(
        'install', '--id', $VSCodeWingetId, '-e',
        '--scope', 'user',
        '--accept-package-agreements', '--accept-source-agreements',
        '--disable-interactivity', '--silent',
        '--override', '/VERYSILENT /NORESTART /MERGETASKS=addtopath,runcode!'
    )
    & winget @wingetArgs
    if (-not (Test-WingetExitOk -ExitCode $LASTEXITCODE) -and -not (Test-VSCodePresentOnMachine)) {
        throw "VS Code non installe (winget code $LASTEXITCODE). Essaie https://code.visualstudio.com puis relance install-madhackademy.cmd"
    }
}

function Ensure-VSCodeInPath {
    if (Get-Command code -ErrorAction SilentlyContinue) {
        return $true
    }

    foreach ($dir in Get-VSCodeBinDirs) {
        $codeCmd = Join-Path $dir "code.cmd"
        if (-not (Test-Path $codeCmd)) {
            continue
        }

        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        if ($userPath -split ';' | Where-Object { $_ -ieq $dir }) {
            $env:Path = "$dir;$env:Path"
            return $true
        }

        if ($DryRun) {
            Write-Warn "DryRun : ajouterait $dir au PATH utilisateur"
            return $true
        }

        $newPath = if ([string]::IsNullOrWhiteSpace($userPath)) { $dir } else { "$userPath;$dir" }
        [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
        $env:Path = "$dir;$env:Path"
        Write-Ok "PATH utilisateur : $dir"
        return $true
    }

    return $false
}

function Install-WingetPackage {
    param(
        [string]$Id,
        [string]$Label,
        [string]$Scope = ""
    )

    if (-not (Test-WingetAvailable)) {
        throw "winget introuvable. Installe App Installer (Microsoft Store) ou suis NOTE_SETUP-UTILISATEUR.md (installation manuelle)."
    }

    if ($DryRun) {
        $scopeMsg = if ($Scope) { " scope $Scope" } else { "" }
        Write-Warn "DryRun : winget install --id $Id$scopeMsg"
        return
    }

    $scopeMsg = if ($Scope) { " (scope $Scope)" } else { "" }
    Write-Host "Installation $Label via winget$scopeMsg..."
    $wingetArgs = @(
        'install', '--id', $Id, '-e',
        '--accept-package-agreements', '--accept-source-agreements',
        '--disable-interactivity'
    )
    if ($Scope) {
        $wingetArgs += @('--scope', $Scope)
    }
    if ($Unattended) {
        $wingetArgs += '--silent'
    }
    & winget @wingetArgs
    if (-not (Test-WingetExitOk -ExitCode $LASTEXITCODE)) {
        throw "winget a echoue pour $Id$scopeMsg (code $LASTEXITCODE)"
    }
}

function Install-LovePortableZip {
    if (Test-LovePresent) {
        return
    }

    $version = $LovePortableVersion
    $url = "https://github.com/love2d/love/releases/download/$version/love-$version-win64.zip"
    $destRoot = Join-Path $env:LOCALAPPDATA "Programs\LOVE"
    $zipPath = Join-Path $env:TEMP "love-$version-win64.zip"

    if ($DryRun) {
        Write-Warn "DryRun : telechargerait $url vers $destRoot"
        return
    }

    Write-Host "Installation LOVE portable (zip GitHub $version)..."
    if (Test-Path $zipPath) {
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
    }
    Invoke-WebRequest -Uri $url -OutFile $zipPath -UseBasicParsing

    if (-not (Test-Path $destRoot)) {
        New-Item -ItemType Directory -Path $destRoot -Force | Out-Null
    }

    Expand-Archive -LiteralPath $zipPath -DestinationPath $destRoot -Force
    Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue

    $nested = Join-Path $destRoot "love-$version-win64"
    if (Test-Path -LiteralPath $nested) {
        Get-ChildItem -LiteralPath $nested | ForEach-Object {
            $target = Join-Path $destRoot $_.Name
            if (Test-Path -LiteralPath $target) {
                Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue
            }
            Move-Item -LiteralPath $_.FullName -Destination $destRoot -Force
        }
        Remove-Item -LiteralPath $nested -Force -ErrorAction SilentlyContinue
    }

    if (-not (Test-LovePresent)) {
        throw "LOVE portable extrait mais love.exe introuvable dans $destRoot"
    }
    Write-Ok "LOVE portable : $(Get-LoveExecutable)"
}

function Install-LoveViaWinget {
    if (Test-LovePresent) {
        return
    }

    # Love2d.Love2d : souvent scope machine uniquement (pas LOVE.LOVE obsolete)
    $wingetAttempts = @(
        @{ Scope = "" },
        @{ Scope = "machine" },
        @{ Scope = "user" }
    )

    foreach ($attempt in $wingetAttempts) {
        try {
            Install-WingetPackage -Id $LoveWingetId -Label 'LOVE' -Scope $attempt.Scope
        }
        catch {
            $s = if ($attempt.Scope) { $attempt.Scope } else { "default" }
            Write-Warn "winget LOVE ($s) : $($_.Exception.Message)"
        }
        if (Test-LovePresent) {
            Write-Ok "LOVE detecte : $(Get-LoveExecutable)"
            return
        }
        Start-Sleep -Seconds 2
    }

    try {
        Install-LovePortableZip
    }
    catch {
        Write-Warn "LOVE portable : $($_.Exception.Message)"
    }

    if (Test-LovePresent) {
        return
    }

    throw "LOVE introuvable. Installe Love2d depuis https://love2d.org ou relance en admin (winget machine)."
}

function Test-LuaExtensions {
    if (-not (Get-VSCodeExtensionCli)) {
        return $false
    }

    $installed = Get-InstalledVSCodeExtensions
    foreach ($ext in $LuaExtensions) {
        if ($installed -notcontains $ext) {
            return $false
        }
    }
    return $true
}

function Install-LuaExtensions {
    if (-not (Get-VSCodeExtensionCli)) {
        Write-Warn "code indisponible - extensions Lua ignorees"
        return $false
    }

    $installed = Get-InstalledVSCodeExtensions
    $allOk = $true
    foreach ($ext in $LuaExtensions) {
        if ($installed -contains $ext) {
            Write-Ok "Extension deja presente : $ext"
            continue
        }
        if ($DryRun) {
            Write-Warn "DryRun : code --install-extension $ext"
            continue
        }

        Write-Host "Extension : $ext"
        $exitCode = Invoke-VSCodeCli -Arguments @('--install-extension', $ext, '--force')
        if ($exitCode -ne 0 -and $Unattended) {
            Write-Host "  Retry via VSIX marketplace..."
            try {
                $vsix = Join-Path $env:TEMP ("flashdev-" + ($ext -replace '\.', '-') + ".vsix")
                Invoke-WebRequest -Uri (Get-MarketplaceVsixUrl -ExtensionId $ext) -OutFile $vsix -UseBasicParsing
                $exitCode = Invoke-VSCodeCli -Arguments @('--install-extension', $vsix, '--force')
                Remove-Item $vsix -Force -ErrorAction SilentlyContinue
            }
            catch {
                Write-Warn "Telechargement VSIX echoue : $($_.Exception.Message)"
            }
        }
        if ($exitCode -ne 0) {
            Write-Warn "Echec extension $ext (code $exitCode)"
            $allOk = $false
        }
        else {
            Write-Ok "Extension installee : $ext"
        }
    }
    return $allOk
}

function Get-FlashDevIconPath {
    $icoCandidates = @(
        (Join-Path $repoRoot "FlashDev-shortcut.ico"),
        (Join-Path $repoRoot "installer\FlashDev-shortcut.ico"),
        (Join-Path $repoRoot "installer\assets\FlashDev-shortcut.ico"),
        (Join-Path $repoRoot "FlashDev-setup.ico"),
        (Join-Path $repoRoot "installer\FlashDev-setup.ico"),
        (Join-Path $repoRoot "FlashDev.ico"),
        (Join-Path $repoRoot "installer\FlashDev.ico"),
        (Join-Path $repoRoot "installer\assets\FlashDev.ico")
    )
    return ($icoCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
}

function New-FlashDevLauncherShortcut {
    param(
        [string]$ShortcutPath,
        [string]$TargetLove = '',
        [string]$GamePath = $gameDir,
        [string]$Description = 'FlashDev - revisions MadHackademy'
    )

    if (-not $TargetLove) {
        $TargetLove = Get-LoveExecutable
    }
    if (-not $TargetLove -or -not (Test-Path -LiteralPath $TargetLove)) {
        Write-Warn "Raccourci ignore : LOVE introuvable ($ShortcutPath)"
        return $false
    }

    $iconPath = Get-FlashDevIconPath

    if ($DryRun) {
        Write-Warn "DryRun : raccourci $ShortcutPath"
        return $true
    }

    $wsh = New-Object -ComObject WScript.Shell
    $shortcut = $wsh.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = $TargetLove
    $shortcut.Arguments = "`"$GamePath`""
    $shortcut.WorkingDirectory = $GamePath
    $shortcut.Description = $Description
    if ($iconPath) {
        $shortcut.IconLocation = "$iconPath,0"
    }
    $shortcut.Save()
    return $true
}

function New-FlashDevInstallFolderShortcut {
    $shortcutPath = Join-Path $repoRoot "FlashDev MadHackademy.lnk"
    if (New-FlashDevLauncherShortcut -ShortcutPath $shortcutPath) {
        Write-Ok "Raccourci dossier install : FlashDev MadHackademy.lnk"
    }
}

function New-FlashDevDesktopShortcut {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktop "FlashDev MadHackademy.lnk"
    if (New-FlashDevLauncherShortcut -ShortcutPath $shortcutPath) {
        Write-Ok "Raccourci Bureau : FlashDev MadHackademy"
    }
}

function Invoke-VerifyReport {
    $results = [ordered]@{}

    $results['LOVE'] = Test-LoveInstalled
    $results["VS Code (code)"] = Test-VSCodeInstalled -and (Get-Command code -ErrorAction SilentlyContinue)
    $results["Extensions Lua"] = Test-LuaExtensions
    $results["FlashDev (main.lua)"] = Test-Path $mainLua

    Write-Step "Rapport de verification"
    Write-Host "Dossier jeu : $gameDir"
    Write-Host ""

    $allOk = $true
    foreach ($entry in $results.GetEnumerator()) {
        if ($entry.Value) {
            Write-Ok $entry.Key
        }
        else {
            Write-Fail $entry.Key
            $allOk = $false
        }
    }

    if (-not $allOk) {
        Write-Host ""
        Write-Warn "Des elements manquent. Relance install-madhackademy.ps1 ou voir scripts/NOTE_SETUP-UTILISATEUR.md"
        if (-not $Unattended) {
            Read-Host "Entree pour fermer"
        }
        return 1
    }

    Write-Host ""
    Write-Ok "Environnement pret pour FlashDev."
    if (-not $Unattended) {
        Read-Host "Entree pour fermer"
    }
    return 0
}

# --- Main ---

Write-Host ""
Write-Host "FlashDev MadHackademy - installation socle" -ForegroundColor White
Write-Host "Repo : $repoRoot"

if ($VerifyOnly) {
    exit (Invoke-VerifyReport)
}

if (-not (Test-Path $mainLua)) {
    throw "FlashDev introuvable : $mainLua (decompresse ou clone FlashRevisionSoft avant installation)"
}

# LÖVE
if (-not $SkipLove) {
    Write-Step "LOVE 11.x"
    if (Test-LoveInstalled) {
        Write-Ok "Deja installe : $(Get-LoveExecutable)"
    }
    elseif ($DryRun) {
        Write-Warn "DryRun : installerait LOVE"
    }
    else {
        Install-LoveViaWinget
    }
}

# VS Code
if (-not $SkipVSCode) {
    Write-Step "Visual Studio Code"
    if (Test-VSCodePresentOnMachine) {
        $roots = @(Get-VSCodeInstallRoots)
        if ($roots.Count -gt 0) {
            Write-Ok "VS Code deja present : $($roots[0])"
        }
        else {
            Write-Ok "VS Code deja present (code.cmd)"
        }
    }
    elseif (Test-VSCodeInstalled) {
        Write-Ok "VS Code detecte"
    }
    elseif ($DryRun) {
        Write-Warn "DryRun : installerait VS Code"
    }
    else {
        Install-VSCodeForFlashDev
    }

    if (Ensure-VSCodeInPath) {
        Write-Ok "Commande code disponible"
    }
    elseif (Test-VSCodePresentOnMachine) {
        Write-Warn 'code absent du PATH : rouvrir PowerShell ou ajouter manuellement ...\Microsoft VS Code\bin'
    }
    else {
        Write-Warn 'code introuvable - reinstalle VS Code en cochant Ajouter au PATH'
    }
}

# Extensions Lua
if (-not $SkipExtensions) {
    Write-Step "Extensions VS Code (Lua / Love2D)"
    if (Test-LuaExtensions) {
        Write-Ok "Extensions Lua deja installees"
    }
    else {
        Install-LuaExtensions | Out-Null
    }
}

# Raccourci dossier d installation (LOVE + icone FlashDev.ico, pas FlashDev.cmd)
Write-Step "Raccourci dossier FlashDev"
New-FlashDevInstallFolderShortcut

# Raccourci Bureau
if (-not $NoDesktopShortcut) {
    Write-Step "Raccourci Bureau"
    New-FlashDevDesktopShortcut
}

exit (Invoke-VerifyReport)
