@echo off
REM Reset VS Code + LOVE pour retest installeur FlashDev (voir reset-flashdev-socle-test.ps1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0reset-flashdev-socle-test.ps1" %*
