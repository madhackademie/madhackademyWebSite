@echo off
REM Lance FlashDev via resolve-love.ps1 + install winget si besoin
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run-love.ps1"
if errorlevel 1 (
  echo.
  echo LOVE introuvable ou installation echouee.
  echo Relancez : scripts\install-madhackademy.cmd
  echo Prerequis : Microsoft App Installer (winget) - Microsoft Store
  pause
)
