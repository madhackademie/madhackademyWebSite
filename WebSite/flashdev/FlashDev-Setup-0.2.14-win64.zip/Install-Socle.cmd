@echo off
REM Installation automatique du socle (LÖVE, VS Code, extensions) — sans pause entre etapes.
setlocal
cd /d "%~dp0"

echo.
echo FlashDev - installation automatique du socle...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-madhackademy.ps1" -Unattended %*
set "ERR=%ERRORLEVEL%"

if not "%ERR%"=="0" (
  echo.
  echo [KO] Installation incomplete ^(code %ERR%^).
  pause
  exit /b %ERR%
)

echo.
echo [OK] Socle installe. Lancez FlashDev.cmd ou le raccourci Bureau.
timeout /t 3 /nobreak >nul
exit /b 0
