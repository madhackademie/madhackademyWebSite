--[[
  updateCheck — détection mise à jour (Phase A)
  Ne touche pas aux données de révision (data.json, decks, images user).
  Fetch HTTPS sur le thread principal (io.popen + curl) : les threads LÖVE
  n'achevent pas toujours le worker réseau à temps.
]]

local json = require("json")

local updateCheck = {}

local MANIFEST_URL = "https://gameopenmoney.com/flashdev/latest-version.json"
local NETWORK_TIMEOUT_SEC = 8

local state = {
	status = "idle",
	updateAvailable = false,
	localVersion = nil,
	remoteVersion = nil,
	manifest = nil,
	errorMessage = nil,
}

local co = nil
local onCompleteCallback = nil

local function notifyComplete()
	if onCompleteCallback then
		onCompleteCallback(updateCheck.getState())
	end
end

local function parseVersion(v)
	local major, minor, patch = tostring(v):match("^(%d+)%.(%d+)%.(%d+)$")
	if not major then
		return nil, "format version invalide: " .. tostring(v)
	end
	return { tonumber(major), tonumber(minor), tonumber(patch) }
end

function updateCheck.compareVersions(a, b)
	local va, errA = parseVersion(a)
	local vb, errB = parseVersion(b)
	if not va then
		return nil, errA
	end
	if not vb then
		return nil, errB
	end
	for i = 1, 3 do
		if va[i] > vb[i] then
			return 1
		end
		if va[i] < vb[i] then
			return -1
		end
	end
	return 0
end

function updateCheck.loadLocalVersion(basePath)
	local path = (basePath or "") .. "version.json"
	local ok, result = pcall(function()
		local file = io.open(path, "r")
		if not file then
			error("version.json introuvable: " .. path)
		end
		local content = file:read("*a")
		file:close()
		return json.decode(content)
	end)

	if not ok then
		return nil, result
	end
	if not result or not result.version then
		return nil, "version.json sans champ version"
	end
	return result, nil
end

function updateCheck.getState()
	return {
		status = state.status,
		updateAvailable = state.updateAvailable,
		localVersion = state.localVersion,
		remoteVersion = state.remoteVersion,
		manifest = state.manifest,
		errorMessage = state.errorMessage,
	}
end

function updateCheck.isChecking()
	return state.status == "checking"
end

--- Callback unique : appele une fois quand la coroutine de lancement a fini.
function updateCheck.setOnComplete(fn)
	onCompleteCallback = fn
	if state.status == "done" or state.status == "error" then
		notifyComplete()
	end
end

function updateCheck.clearOnComplete()
	onCompleteCallback = nil
end

local function finishCheck(opts)
	state.status = opts.status or "done"
	state.updateAvailable = opts.updateAvailable or false
	state.remoteVersion = opts.remoteVersion
	state.manifest = opts.manifest
	state.errorMessage = opts.errorMessage

	if opts.errorMessage then
		print("[updateCheck] " .. opts.errorMessage)
	elseif state.updateAvailable then
		print("[updateCheck] Mise a jour disponible: "
			.. tostring(state.localVersion) .. " -> " .. tostring(state.remoteVersion))
	else
		print("[updateCheck] Soft a jour (" .. tostring(state.localVersion) .. ")")
	end

	co = nil
	notifyComplete()
end

local function runCommand(cmd)
	local handle = io.popen(cmd, "r")
	if not handle then
		return nil, "Impossible de lancer la commande reseau"
	end

	local output = handle:read("*a") or ""
	handle:close()
	output = output:gsub("^%s+", ""):gsub("%s+$", "")
	return output, nil
end

local function fetchManifest(url, timeout)
	local netTimeout = tonumber(timeout) or NETWORK_TIMEOUT_SEC
	-- URL sans espaces : pas de guillemets (evite "syntaxe incorrecte" sous cmd/Windows)
	local curlCmd = string.format("curl.exe -s -m %d %s 2>nul", netTimeout, url)
	local output = runCommand(curlCmd)
	if output and output ~= "" and output:match("^%s*{") then
		return output, nil
	end

	local psUrl = tostring(url):gsub("'", "''")
	local psCmd = string.format(
		[[powershell -NoProfile -NonInteractive -Command "& { $ProgressPreference='SilentlyContinue'; try { (Invoke-WebRequest -Uri '%s' -UseBasicParsing -TimeoutSec %d).Content } catch { $_.Exception.Message; exit 1 } }"]],
		psUrl,
		netTimeout
	)
	output = runCommand(psCmd)
	if not output or output == "" then
		return nil, "Requete HTTPS echouee (hors ligne ou serveur indisponible)"
	end
	return output, nil
end

local function processManifestBody(body)
	if not body:match("^%s*{") then
		finishCheck({
			status = "error",
			updateAvailable = false,
			errorMessage = body,
		})
		return
	end

	local decodeOk, manifest = pcall(json.decode, body)
	if not decodeOk or type(manifest) ~= "table" then
		finishCheck({
			status = "error",
			updateAvailable = false,
			errorMessage = "JSON manifest invalide",
		})
		return
	end
	if not manifest.version then
		finishCheck({
			status = "error",
			updateAvailable = false,
			errorMessage = "Manifest sans champ version",
		})
		return
	end

	local cmp, cmpErr = updateCheck.compareVersions(manifest.version, state.localVersion)
	if cmp == nil then
		finishCheck({
			status = "error",
			updateAvailable = false,
			errorMessage = "Comparaison versions: " .. tostring(cmpErr),
		})
		return
	end

	finishCheck({
		status = "done",
		updateAvailable = cmp > 0,
		remoteVersion = manifest.version,
		manifest = manifest,
	})
end

local function runCheckCoroutine()
	-- Laisser une frame s'afficher avant le fetch bloquant (~0,2 s en ligne).
	coroutine.yield()

	local body, fetchErr = fetchManifest(MANIFEST_URL, NETWORK_TIMEOUT_SEC)
	if not body then
		finishCheck({
			status = "error",
			updateAvailable = false,
			errorMessage = fetchErr or "Erreur reseau inconnue",
		})
		return
	end

	processManifestBody(body)
end

function updateCheck.startAsyncCheck(basePath)
	if state.status == "checking" then
		return
	end

	local localInfo, localErr = updateCheck.loadLocalVersion(basePath)
	if not localInfo then
		state.status = "error"
		state.updateAvailable = false
		state.errorMessage = "Version locale: " .. tostring(localErr)
		print("[updateCheck] " .. state.errorMessage)
		notifyComplete()
		return
	end

	state.localVersion = localInfo.version
	state.status = "checking"
	state.updateAvailable = false
	state.remoteVersion = nil
	state.manifest = nil
	state.errorMessage = nil

	co = coroutine.create(runCheckCoroutine)
end

function updateCheck.poll()
	if not co then
		return
	end

	if coroutine.status(co) == "dead" then
		co = nil
		return
	end

	local ok, err = coroutine.resume(co)
	if not ok then
		finishCheck({
			status = "error",
			updateAvailable = false,
			errorMessage = "Coroutine update: " .. tostring(err),
		})
	end
end

return updateCheck
