
local Bouton = Class{}


function Bouton:init(pId,pNomImage,pX,pY,pScale,pRotate,pCallback,pArgs) --init = constructeur
	self.id = pId
	if liste_object and #liste_object >= self.id then 
		self.x = liste_object[self.id].x
		self.y = liste_object[self.id].y
	else 
		self.x = pX 
		self.y = pY 
	end
	self.scale = pScale
	self.rotate = pRotate or 0 
	self.surv = false--si survolé alors true
	self.callback = pCallback
	self.args = pArgs
	self.color={255/255,255/255,255/255,255/255}
	self.enable = true
	self.enableFunc = true
	self.imageBase = love.graphics.newImage("/images_current/buton_Choix-assets/"..pNomImage..".png")
	self.imageSurv = love.graphics.newImage("/images_current/buton_Choix-assets/"..pNomImage.." Surv.png")
	self.largeur = self.imageBase:getWidth()*self.scale or self.imageSurv:getWidht()*self.scale
	self.hauteur = self.imageBase:getHeight()*self.scale or self.imageSurv:getHeight()*self.scale
	self.move = false
	local p = {}
	p.id = self.id
	p.x = math.floor( self.x )
	p.y = math.floor(self.y)
	local control = false
	for i=1,#liste_object do 
		if liste_object[i].id == self.id then 
			control = true 
		end
	end
	if control == false then 
		table.insert(liste_object,p )
		print(#liste_object)
	end
	local file =io.open(objJsonAddress,"w+")--pour ouvrir à partir de la racine dossier courant du main, w pour l'ecriture 
	file:write(json.encode(liste_object,{indent=true}))
	file:flush ()
	file:close()
end


function Bouton:mousepressed(x,y,button)
	if self.enableFunc then
		if self.surv then
			if button == 1 then
				if self.callback then -- verification si fonction liee à l'objet
					if self.args then -- et si cette dernière recoit des arguments en parametre
						self.callback(unpack(self.args)) --alors on traitement de la fonction avec arg
					else
						self.callback()
					end
				end
			end
			if button == 2 then 
				self.move = true
			end
		end
	end
end

function Bouton:mousereleased(x,y, button )
	if self.enableFunc then
		if button == 2 then 
			self.move = false
			if self.surv then
				print("X = ",math.floor(self.x)," Y = ",math.floor(self.y))
				--if liste_object and #liste_object >= self.id then 
				liste_object[self.id].x = self.x
				liste_object[self.id].y = self.y
				local file =io.open(objJsonAddress,"w+")--pour ouvrir à partir de la racine dossier courant du main, w pour l'ecriture 
				--voir pour plus de portabilité d'utiliser le fileSysteme de love
				file:write(json.encode(liste_object,{indent=true}))
				file:flush ()
				file:close()
			end
		end
	end
end

function Bouton:update(dt)
	mouseX = love.mouse:getX()
	mouseY = love.mouse:getY()
	--if self.enable then
		if mouseX >= self.x - self.largeur/2 and mouseX <= self.x + self.largeur/2 then
			if mouseY >= self.y - self.hauteur/2 and mouseY <= self.y + self.hauteur/2 then
				self.surv=true
			else
				self.surv=false
			end
		else
			self.surv=false
			self.clicable = false
		end  
	if self.move then 
		self.x = math.floor(mouseX)
		self.y = math.floor(mouseY)
	end	
end


function Bouton:draw()
	love.graphics.setColor(self.color)
	if self.enable then
		self.color={255/255,255/255,255/255,255/255}--new version love2d color = 0 à 1 donc diviser les couleurs par 255 
		if self.surv == false then
			love.graphics.draw(self.imageBase,self.x,self.y,math.rad(self.rotate),self.scale,self.scale,self.imageBase:getWidth()/2,self.imageBase:getHeight()/2)
		elseif self.surv == true then
			love.graphics.draw(self.imageSurv,self.x,self.y,math.rad(self.rotate),self.scale,self.scale,self.imageSurv:getWidth()/2,self.imageSurv:getHeight()/2)
		end
	else
		self.color={255/255,255/255,255/255,70/255}
		love.graphics.draw(self.imageBase,self.x,self.y,math.rad(self.rotate),self.scale,self.scale,self.imageBase:getWidth()/2,self.imageBase:getHeight()/2)
	end
	love.graphics.setColor(255/255,255/255,255/255,255/255)
end

return Bouton

