--[[
  OBSOLETE — Phase A utilise updateCheck.lua (thread principal + curl.exe).
  Conserve pour historique ; non charge par le soft.
]]
