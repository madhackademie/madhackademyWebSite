menuStream = {}

function menuStream:enter(oldState)
	menu_Image = love.graphics.newImage("images/menuProdStream.png")
	----------------- VARIABLE MENU------------------------

	perlin = love.filesystem.read("perlin2d.glsl")
	shader = love.graphics.newShader(perlin..[[extern number camposy;vec4 effect(vec4 colour, Image image, vec2 local, vec2 screen)
			{
				vec2 offset = vec2(screen.x, screen.y+camposy*-100);
				number noise = perlin2d(offset / 128.0);
				noise = noise * 0.5 + 0.5;
				return vec4(noise, noise, noise, 1.0)*colour;
			}]])
		   
	rgbColor = {53/255,101/255,232/255}


	TimerShaderColor = 0
			
	tableSheetAvatar = {}
	tableSheetAvatar[1] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/avatYDown.png")
	tableSheetAvatar[2] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/avatYLeft.png")
	tableSheetAvatar[3] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/avatYUp.png")
	tableSheetAvatar[4] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/avatYRight.png")
	tableSheetAvatar[5] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/avatLunetteLeft.png")
	tableSheetAvatar[6] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/avatLunetteRight.png")
	tableSheetAvatar[7] = love.graphics.newImage("images/spriteSheet/menu/avatarAnime/personalisationAutoDerision.png")
	avatarCurrentSprite = 1

	tableSheetNom = {}
	local n
		for n=1,8 do
		  tableSheetNom[n] = love.graphics.newImage("images/spriteSheet/menu/animationLogo/logo_"..n..".png")
		end
		nomCurrentSprite = 1
end

function menuStream:update(dt) 
	
	avatarCurrentSprite = avatarCurrentSprite + (3*dt)
  if math.floor(avatarCurrentSprite) > #tableSheetAvatar then
    avatarCurrentSprite = 1
  end
  
  nomCurrentSprite = nomCurrentSprite + (5*dt)
  if math.floor(nomCurrentSprite) > #tableSheetNom then
    nomCurrentSprite = 8
  end
  TimerShaderColor = TimerShaderColor + (3*dt)
  shader:send("camposy",TimerShaderColor)
  
   if TimerShaderColor >= 0 and TimerShaderColor < 11 then--blue
        rgbColor = { 53/255, 101/255, 232/255 }
    elseif TimerShaderColor >= 11 and TimerShaderColor < 21 then--green
        rgbColor = { 66/255, 244/255, 72/255 }
    elseif TimerShaderColor >= 21 and TimerShaderColor < 35 then--yellow
        rgbColor = { 241/255, 194/255, 64/255 }
    elseif TimerShaderColor >=35 and TimerShaderColor < 45 then -- red
        rgbColor = { 237/255, 25/255, 14/255 }
    elseif TimerShaderColor >= 45 and TimerShaderColor <55 then-- purple
        rgbColor = { 110/255, 7/255, 237/255 }
    elseif TimerShaderColor >=55 and TimerShaderColor < 65 then--turquoise
        rgbColor = { 7/255, 233/255, 237/255 }
    elseif TimerShaderColor >65 then
      TimerShaderColor=1
    end
end


function menuStream:draw()
	
love.graphics.setShader(shader)
    love.graphics.setColor(rgbColor)
    love.graphics.rectangle("fill",0,0,1024,768)
    love.graphics.setColor(255/255,255/255,255/255)
love.graphics.setShader()
--  love.graphics.draw(menu_Image,0,0)
    love.graphics.draw(tableSheetNom[math.floor(nomCurrentSprite)],600, hauteur/3,0,3,4,tableSheetNom[math.floor(nomCurrentSprite)]:getWidth()/2,tableSheetNom[math.floor(nomCurrentSprite)]:getHeight()/2)
  love.graphics.draw(tableSheetAvatar[math.floor(avatarCurrentSprite)],largeur/2, hauteur/4*2.5,0,2,2,tableSheetAvatar[math.floor(avatarCurrentSprite)]:getWidth()/2,tableSheetAvatar[math.floor(avatarCurrentSprite)]:getHeight()/2)
	
end

function menuStream:keypressed(key)
	if key=="space" then
		stateManager.switch(currentProjectMenu)
	end
end


return menuStream
	