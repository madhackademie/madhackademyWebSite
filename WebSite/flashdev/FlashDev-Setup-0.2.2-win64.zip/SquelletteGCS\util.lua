local util =  {}

--CHARGEMENT D UN JSON DANS UNE TABLE--
--[[
  local table = {}
  table = loadJson("c:va/voir/allieurs.json")
]]
function util.shallowcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in pairs(orig) do
            copy[orig_key] = orig_value
        end
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end


function util.resolveBasePath()
	local candidates = {
		love.filesystem.getSourceBaseDirectory(),
		love.filesystem.getWorkingDirectory(),
		love.filesystem.getWorkingDirectory() .. "/SquelletteGCS",
	}
	for _, base in ipairs(candidates) do
		if base and base ~= "" then
			base = base:gsub("\\", "/")
			if not base:match("/$") then
				base = base .. "/"
			end
			local file = io.open(base .. "data.json", "r")
			if file then
				file:close()
				return base
			end
		end
	end
	error("Impossible de trouver data.json (lancez LÖVE depuis le dossier SquelletteGCS)")
end

function util.loadJson(name)
	local data = love.filesystem.read(name)
	if not data then
		local file = io.open(name, "r")
		if not file then
			error("Impossible de lire le JSON : " .. tostring(name))
		end
		data = file:read("*a")
		file:close()
	end
	return json.decode(data)
end
	
function util.print (t) 
	local print_cache={}
	local function sub_print(t,indent)
		if (print_cache[tostring(t)]) then
			print(indent.."*"..tostring(t))
		else
			print_cache[tostring(t)]=true
			if (type(t)=="table") then
				for pos,val in pairs(t) do
					if (type(val)=="table") then
						print(indent.."["..pos.."] => "..tostring(t).." {")
						sub_print(val,indent..string.rep(" ",string.len(pos)+8))
						print(indent..string.rep(" ",string.len(pos)+6).."}")
					elseif (type(val)=="string") then
						print(indent.."["..pos..'] => "'..val..'"')
					else
						print(indent.."["..pos.."] => "..tostring(val))
					end
				end
			else
				print(indent..tostring(t))
			end
		end
	end
	if (type(t)=="table") then
		print(tostring(t).." {")
		sub_print(t,"  ")
		print("}")
	else
		sub_print(t,"  ")
	end
	print()
end-- la virgule permet de fermer l'element du tableau ici print = util[1]

function util.clamp(value,min,max)
	if value < min then value = min end
	if value > max then value = max end
	return value
end

function util.loadListCarte()
    local liste_cartes = util.loadJson("data.json")
    local liste_revision = {}
    
    if liste_cartes == nil then 
        liste_cartes = {}
    end

    for i = 1, #liste_cartes do 
        local nextRevision = liste_cartes[i].nextRevision or 0
        if nextRevision <= os.time() then
            table.insert(liste_revision, liste_cartes[i])
        end
    end
    
    return liste_cartes, liste_revision
end


	
return util

