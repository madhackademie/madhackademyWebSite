@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-madhackademy.ps1" %*
