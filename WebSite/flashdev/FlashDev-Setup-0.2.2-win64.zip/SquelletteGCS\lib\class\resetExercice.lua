local ResetExercice = Class{}

--local source = "C:\\chemin\\vers\\source"
--local destination = "C:\\chemin\\vers\\destination"
--local batFile = "reset_project.bat"

--[[--------------------------------------------------------------------------------------------------------
	§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
--  il s'agit ici de faire uniquement le control pour voir et ou créer le bat de reset de l'exercice.
    il n'y a pas d'execution du .bat ici 
	§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
--]]--

function ResetExercice:init(pSource,pDestination,pBatFile) --init = constructeur
    self.source = pSource
    self.destination = pDestination
    self.batFile = pBatFile
end

--Vérifie si un fichier existe appel interne l.87
local function file_exists(path)
    local file = io.open(path, "r")
    if file then file:close() return true else return false end
end

-- Lit le contenu du fichier appel interne l.45
local function read_file(path)
    local file = io.open(path, "r")
    if not file then return nil end
    local content = file:read("*a")
    file:close()
    return content
end

-- Génère le contenu attendu du .bat appel interne l.62
local function generate_bat_content(sourcePath, destinationPath)
    return table.concat({
        "@echo off",
        'rmdir /s /q "' .. destinationPath .. '"',
        'mkdir "' .. destinationPath .. '"',
        'xcopy "' .. sourcePath .. '\\*" "' .. destinationPath .. '\\" /E /H /C /I',
        ""
    }, "\n")
end

-- Vérifie si le chemin est correct (existe et correspond) appel interne l.65
local function is_bat_up_to_date(path, expectedContent)
    local currentContent = read_file(path)
    return currentContent == expectedContent
end

-- Vérifie l'existence des dossiers
local function folder_exists(path)
    local ok, _, code = os.rename(path, path)
    return ok or code == 13
end

-- Validation des chemins avant d'aller plus loin
function ResetExercice:path_validation()
    if not folder_exists(self.source) then
        print("Erreur : le dossier source n'existe pas : " .. self.source)
        return false
    end
    if not folder_exists(self.destination) then
        print("Erreur : le dossier destination n'existe pas : " .. self.destination)
        return false
    end
    return true
end

local function path_validation()
    if not folder_exists(self.source) then
        print("Erreur : le dossier source n'existe pas : " .. self.source)
        return
    end
end
--appel exterieur de l'obj

function ResetExercice:reset()
    --validation existance du dossier source 
    if not self:path_validation() then print("pas de path") return end
    -- Génére le contenu du .bat attendu
    local expectedBatContent = generate_bat_content(self.source, self.destination)

    -- Crée ou met à jour le fichier .bat si nécessaire
    if not file_exists(self.batFile) or not is_bat_up_to_date(self.batFile, expectedBatContent) then
        local file = io.open(self.batFile, "w")
        if file then
            file:write(expectedBatContent)
            file:close()
            print("Fichier .bat mis à jour.")
        else
            print("Erreur : impossible de créer le fichier .bat.")
            return
        end
    else
        print("Fichier .bat à jour, aucune modification nécessaire.")
    end
end

return ResetExercice

