cardModfier = {}

function cardModfier:enter(oldstate)
    -- print(x,y)
    self.oldstate = oldstate
    
--[[--------------------------------------------------------------------------------------------------------
-- BUTTON TABLE
--]]--

    --self.menuButton = {}
	-- self.menuButton.back = Bouton(5,"back",largeur/6,hauteur - 60 ,1,0,		
    -- function()
    --     stateManager.switch(currentProjectMenu)
    -- end)
    -- self.menuButton.name = Bouton(6,"name",150,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.URLexercice = Bouton(7,"urlExercice_exe",150,150,1,0,
    -- function ()

    -- end)
    -- self.menuButton.URLNet = Bouton(8,"urlNet",150,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.URLBat = Bouton(9,"urlCloseAll_bat",150,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.Vid = Bouton(10,"urlVideo",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.Sound = Bouton(11,"urlSound",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.Image = Bouton(12,"urlImage",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.Folder = Bouton(13,"folder",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.ClearAllBat = Bouton(14,"urlClearAll_bat",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.Tag = Bouton(15,"tag",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)
    -- self.menuButton.Add = Bouton(16,"add",300,150,1,0,
    -- function ( ... )
    --     -- body
    -- end)

--[[--------------------------------------------------------------------------------------------------------
-- TEXTBOX TABLE
--]]--
    --self.menuTextBox = {}

    -- self.menuTextBox.nomCarte = Textbox(1000,30,self.menuButton.name.x + self.menuButton.name.largeur/2,self.menuButton.name.y )--,self.menuButton.newCard.x + self.menuButton.newCard.largeur,0)--self.menuButton.newCard.y)
    -- self.menuTextBox.exercice = Textbox(1000,30,self.menuButton.URLexercice.x + self.menuButton.URLexercice.largeur/2,self.menuButton.URLexercice.y )
    -- self.menuTextBox.URLNet = Textbox(1000,30,self.menuButton.URLNet.x + self.menuButton.URLNet.largeur/2,self.menuButton.URLNet.y )
    -- self.menuTextBox.URLBat = Textbox(1000,30,self.menuButton.URLBat.x + self.menuButton.URLBat.largeur/2,self.menuButton.URLBat.y )
    -- self.menuTextBox.URLVid = Textbox(1000,30,self.menuButton.Vid.x + self.menuButton.Vid.largeur/2,self.menuButton.Vid.y )
    -- self.menuTextBox.URLSound = Textbox(1000,30,self.menuButton.Sound.x + self.menuButton.Sound.largeur/2,self.menuButton.Sound.y )
    -- self.menuTextBox.URLImage = Textbox(1000,30,self.menuButton.Image.x + self.menuButton.Image.largeur/2,self.menuButton.Image.y )
    -- self.menuTextBox.URLFolder = Textbox(1000,30,self.menuButton.Folder.x + self.menuButton.Folder.largeur/2,self.menuButton.Folder.y )
    -- self.menuTextBox.URLClearAll = Textbox(1000,30,self.menuButton.ClearAllBat.x + self.menuButton.ClearAllBat.largeur/2,self.menuButton.ClearAllBat.y )
    -- self.menuTextBox.Tag = Textbox(1000,30,self.menuButton.Tag.x + self.menuButton.Tag.largeur/2,self.menuButton.Tag.y )
    
    

    
end

function cardModfier:mousepressed(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end
end

function cardModfier:mousereleased(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end

function cardModfier:textinput (text)
	for k,v in pairs(self.menuTextBox) do
		if v.enable then 
            v.text = v.text..text
            
		end
	end
end-- 

function cardModfier:update( dt )
    for k,button in pairs (self.menuButton) do
        button:update(dt)
    end
	for key,box in pairs(self.menuTextBox) do
		box:update(dt)
	end
end


function cardModfier:draw()

    for k,button in pairs (self.menuButton) do
        button:draw()
    end
    for key,box in pairs(self.menuTextBox) do
		box:draw()
	end
--[[--------------------------------------------------------------------------------------------------------
        affichage d'un etat sur un autre etat
        1) possibilité via le oldstate de lire/ecrire les variables du oldstate(etat arriere plan) ATTENTION les variables etat
            doivent etre en .self pour que cela fonctionne
         //ici mise en pause avec arriere plan inactif et filtre
--]]--
    -- self.oldstate:draw()
    -- love.graphics.setColor(0,0,0,0)
    -- love.graphics.rectangle("fill",0,0,largeur,hauteur)
    -- love.graphics.setColor(255,0,0)
    -- love.graphics.rectangle("fill",200,500,400,500)
    -- love.graphics.setColor(255,255,255)

end

function cardModfier:keypressed(key)
    for k,v in pairs(self.menuTextBox) do
        if v.enable then 
            if key == "backspace" then
                -- get the byte offset to the last UTF-8 character in the string.
                local byteoffset = utf8.offset(v.text, -1)

                if byteoffset then
                    -- remove the last UTF-8 character.
                    -- string.sub operates on bytes rather than UTF-8 characters, so we couldn't do string.sub(text, 1, -2).
                    self.menuTextBox[k].text = string.sub(v.text, 1, byteoffset - 1)
                end
            end
        end
    end
    if key == "lctrl" then-- and key == "v" then 
        for k,v in pairs(self.menuTextBox) do
            if v.enable then 
                v.text = v.text..copyPast
            end
        end
    end
    -- if key == "up" then
    --     self.oldstate.currentCard = self.oldstate.currentCard + 1
    -- end
end


return cardModfier