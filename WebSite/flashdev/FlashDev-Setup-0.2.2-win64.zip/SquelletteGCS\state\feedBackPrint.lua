feedBackPrint = {}

function feedBackPrint:enter(oldstate,text,imageFile)
    self.oldstate = oldstate
    c_printf = {
                    {255/255,255/255,255/255},
                    "MESSAGE   :    ",
                    {255/255,0/255,0/255},
                    tostring(text)
                }
    if(imageFile~=nil) then
        self.image = imageFile
    end
        --[[--------------------------------------------------------------------------------------------------------
-- BUTTON TABLE
--]]--

    self.menuButton = {}
	self.menuButton.back = Bouton(27,"back",largeur/6,hauteur - 60 ,1,0,
    function()
    stateManager.pop()
    end)

--[[--------------------------------------------------
-- TEXTBOX TABLE
--]]--

    self.menuTextBox = {}
     
end

function feedBackPrint:mousepressed(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end
end

function feedBackPrint:mousereleased(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end

function feedBackPrint:update( dt )
    for k,button in pairs (self.menuButton) do
        button:update(dt)
    end
	for key,box in pairs(self.menuTextBox) do
		box:update(dt)
	end
end


function feedBackPrint:draw()
    for k,button in pairs (self.menuButton) do
        button:draw()
    end
    love.graphics.printf(c_printf,0,100,largeur, "center")
    for key,box in pairs(self.menuTextBox) do
		box:draw()
	end
    if self.image ~= nil then
        love.graphics.draw(self.image,250,225,0,1.25,1.25)
    end
end

return feedBackPrint