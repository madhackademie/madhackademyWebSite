currentProjectMenu = {}

local OPTIONS_MENU_GAP = 6
local OPTIONS_MENU_BUTTON_SCALE = 1

local function drawOptionsUpdateHalo(button, phase)
	local cx, cy = button.x, button.y
	local baseR = math.max(button.largeur, button.hauteur) * 0.52 + 4
	local t = phase or 0
	local pulse = 0.5 + 0.5 * math.sin(t * 2.6)
	local shimmer = 0.5 + 0.5 * math.sin(t * 5.4 + 0.8)

	love.graphics.push("all")
	love.graphics.setBlendMode("add")

	for i = 1, 3 do
		local wobble = math.sin(t * 3.8 + i * 1.9)
		local r = baseR + 8 + i * 9 + wobble * 3 + pulse * 4
		local alpha = (0.05 + 0.11 * shimmer) * (i / 3)
		local green = 0.48 + 0.28 * (i / 3)
		love.graphics.setColor(1, green, 0.04, alpha)
		love.graphics.circle("fill", cx, cy, r, 32)
	end

	local ringR = baseR + 24 + pulse * 6 + shimmer * 3
	love.graphics.setColor(1, 0.62 + 0.18 * shimmer, 0.08, 0.18 + 0.42 * pulse * shimmer)
	love.graphics.setLineWidth(1.2 + 1.8 * shimmer)
	love.graphics.circle("line", cx, cy, ringR, 40)

	love.graphics.pop()
end

local function pointInButton(button, x, y)
	return x >= button.x - button.largeur / 2
		and x <= button.x + button.largeur / 2
		and y >= button.y - button.hauteur / 2
		and y <= button.y + button.hauteur / 2
end

function currentProjectMenu:closeOptionsMenu()
	self.optionsMenuOpen = false
	self:setOptionsMenuButtonsActive(false)
end

function currentProjectMenu:openOptionsMenu()
	self:initOptionsMenuButtons()
	self.optionsMenuOpen = true
	self:setOptionsMenuButtonsActive(true)
	self:layoutOptionsMenuButtons()
end

function currentProjectMenu:initOptionsMenuButtons()
	if self.optionsMenuButtons then
		return
	end

	self.optionsMenuButtons = {
		update = Bouton(30, "update", 137, 120, OPTIONS_MENU_BUTTON_SCALE, 0, function()
			if self.updateAvailable then
				self:onUpdateRequested()
			end
		end),
		placeholder = Bouton(31, "underDev", 137, 185, OPTIONS_MENU_BUTTON_SCALE, 0, function()
			print("Option underDev - a venir")
			self:closeOptionsMenu()
		end),
	}

	self:setOptionsMenuButtonsActive(false)
end

function currentProjectMenu:setOptionsMenuButtonsActive(active)
	if not self.optionsMenuButtons then
		return
	end

	for _, button in pairs(self.optionsMenuButtons) do
		button.enableFunc = active
	end

	if active then
		self.optionsMenuButtons.update.enable = self.updateAvailable
		self.optionsMenuButtons.update.enableFunc = active and self.updateAvailable
		self.optionsMenuButtons.placeholder.enable = true
		self.optionsMenuButtons.placeholder.enableFunc = active
	end
end

function currentProjectMenu:layoutOptionsMenuButtons()
	if not self.optionsMenuOpen or not self.optionsMenuButtons then
		return
	end

	local anchor = self.menuButton.options
	local updateButton = self.optionsMenuButtons.update
	local placeholderButton = self.optionsMenuButtons.placeholder
	local itemHeight = updateButton.hauteur
	local startY = anchor.y + anchor.hauteur / 2 + OPTIONS_MENU_GAP + itemHeight / 2

	updateButton.x = anchor.x
	updateButton.y = startY
	placeholderButton.x = anchor.x
	placeholderButton.y = startY + itemHeight + OPTIONS_MENU_GAP
end

function currentProjectMenu:applyUpdateCheckState()
	if not updateCheck then
		return
	end

	local info = updateCheck.getState()
	self.updateAvailable = info.updateAvailable == true

	if self.optionsMenuOpen and self.optionsMenuButtons then
		self.optionsMenuButtons.update.enable = self.updateAvailable
		self.optionsMenuButtons.update.enableFunc = self.updateAvailable
	end
end

function currentProjectMenu:resolveUpdateScriptPath()
	local path = folderBaseAddress:gsub("\\", "/") .. "tools/update-flashdev.ps1"
	local file = io.open(path, "r")
	if file then
		file:close()
		return path:gsub("/", "\\")
	end
	return nil
end

function currentProjectMenu:launchUpdateScript(manifest)
	local scriptPath = self:resolveUpdateScriptPath()
	if not scriptPath then
		print("[update] Script update-flashdev.ps1 introuvable")
		return false
	end

	local downloadUrl = tostring(manifest.downloadUrl or "")
	if downloadUrl == "" then
		print("[update] Manifest sans downloadUrl")
		return false
	end
	if downloadUrl:match("^/") then
		downloadUrl = "https://madhackademy.eu" .. downloadUrl
	end

	local installDir = folderBaseAddress:gsub("/", "\\"):gsub("\\+$", "")
	local sha256 = tostring(manifest.sha256 or ""):gsub('"', "")
	local ps1 = scriptPath:gsub('"', '""')
	local url = downloadUrl:gsub('"', '""')
	local dir = installDir:gsub('"', '""')

	local inner = string.format(
		"-NoProfile -ExecutionPolicy Bypass -File \"%s\" -InstallDir \"%s\" -DownloadUrl \"%s\" -ExpectedSha256 \"%s\"",
		ps1, dir, url, sha256
	)
	local cmd = 'start "FlashDev Update" powershell ' .. inner
	print("[update] Lancement script (Love2D va se fermer)")
	os.execute(cmd)
	return true
end

function currentProjectMenu:onUpdateRequested()
	local info = updateCheck and updateCheck.getState() or {}
	if not info.updateAvailable or not info.manifest then
		print("[update] Aucune mise a jour disponible")
		self:closeOptionsMenu()
		return
	end

	print("Mise a jour demandee: v" .. tostring(info.localVersion)
		.. " -> v" .. tostring(info.remoteVersion))

	self:closeOptionsMenu()

	if self:launchUpdateScript(info.manifest) then
		love.event.quit()
	end
end

function currentProjectMenu:isPointOnOptionsMenu(x, y)
	if not self.optionsMenuOpen or not self.optionsMenuButtons then
		return false
	end

	if pointInButton(self.menuButton.options, x, y) then
		return true
	end

	for _, button in pairs(self.optionsMenuButtons) do
		if button.enableFunc and pointInButton(button, x, y) then
			return true
		end
	end

	return false
end

function currentProjectMenu:updateOptionsMenuButtons(dt)
	if not self.optionsMenuOpen or not self.optionsMenuButtons then
		return
	end

	self:layoutOptionsMenuButtons()

	for _, button in pairs(self.optionsMenuButtons) do
		button:update(dt)
	end
end

function currentProjectMenu:drawOptionsMenu()
	if not self.optionsMenuOpen or not self.optionsMenuButtons then
		return
	end

	self.optionsMenuButtons.update:draw()
	self.optionsMenuButtons.placeholder:draw()
end


--[[--------------------------------------------------------------------------------------------------------
	§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
-- MEMO CODE EDUCATIF attention à la manière d'architecturer son code avec les states. Les requires récupères les éléments hors fonction des states
	dans le main, et les fonctions qui s'execute uniquement lors de l'appel du state. Donc le probleme qui à été ici est : 
	1) la table etait initialiser par le require dans le main.
	2) on apportait une modification de cette table dans une fonction du state
	3) puis on essayais de lire l'index [1] de la table qui n'exitait pas encore vue que modifier dans une fonction du state et pas du main
	pour palier à ce problème soit créer l'initialisation et les calculs dans le main autant que faire se peux soit rester attentif au sens de l'ecture
	globale des différents éléments du code
	cree schema 
	§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
--]]--

function currentProjectMenu:enter(oldstate)
	image = nil

	-- Charger les données à chaque entrée dans le state
    liste_cartes, liste_revision = util.loadListCarte()
    
    -- Réinitialiser currentCard si nécessaire
    if currentCard > #liste_revision then
        currentCard = 1
    end
	
--[[--------------------------------------------------------------------------------------------------------
-- MEMO FOR MYSELF LANCER LA FONCTION LOAD LISTE REVISION ICI 
--]]--
	v_printf = {
		{255/255,255/255,255/255},
		"nombre   de   cartes   a   reviser   :    ",
		{255/255,0/255,0/255},
		tostring(#liste_revision)
	}
	
--[[--------------------------------------------------------------------------------------------------------
--RESET BAT OBJ 
--]]--
	if(#liste_revision > 0) then
		self.resetExercice = {}
		self.resetExercice.currentCard = ResetExercice(
			folderBaseAddress..liste_revision[currentCard].URLCopy,
			folderBaseAddress..liste_revision[currentCard].URLExercice,
			folderBaseAddress..liste_revision[currentCard].URLExerciceResetBat
		)
	end
--[[--------------------------------------------------------------------------------------------------------
-- LISTE DES BOUTONS ET FONCTIONS ASSOCIES
--]]--
	self.menuButton = {}
	self.optionsMenuOpen = false
	self.optionsMenuButtons = nil
	self.updateAvailable = false -- true quand une version distante plus recente est detectee
	self.optionsHaloPhase = 0

	self.menuButton.newCard = Bouton(2,"new card",50,50,1,0,
	function()
		stateManager.push(addNewCard)
	end)


	self.menuButton.arrowRight = Bouton(3,"arrow",(largeur/6)+25,100,0.5,0,
	function()
		if currentCard<#liste_revision then
			currentCard = currentCard + 1
		else
			currentCard = 1
		end
		if currentCard > 0 then 
			image = love.graphics.newImage(liste_revision[currentCard].URLImage)
			c_printf = {
				{255/255,255/255,255/255},
				"Carte a reviser   :    ",
				{255/255,0/255,0/255},
				tostring(liste_revision[currentCard].nom)
			}
		end
	end)
	
	self.menuButton.arrowLeft = Bouton(4,"arrow",(largeur/6)-25,100,0.5,180,
	function()
		if currentCard > 1 then
			currentCard = currentCard - 1
		else
			currentCard = #liste_revision
		end
		if currentCard > 0 then 
			image = love.graphics.newImage(liste_revision[currentCard].URLImage)
			c_printf = {
				{255/255,255/255,255/255},
				"Carte a reviser   :    ",
				{255/255,0/255,0/255},
				tostring(liste_revision[currentCard].nom)
			}
		end
	end)

	if #liste_revision > 0 then 
		c_printf = {
			{255/255,255/255,255/255},
			"Carte a reviser   :    ",
			{255/255,0/255,0/255},
			tostring(liste_revision[currentCard].nom)
		}
	end

	self.menuButton.start = Bouton(1,"start",0,0,1,0,		
	function()
		if #liste_revision > 0 then 
			self.url =folderBaseAddress..liste_revision[currentCard].URLFolder
			--[[reset if set for this card in case whe did mess up at the end of the exercice
			--and it hapen often.
			--controle du bat avant execution]]
			if(liste_revision[currentCard].URLExerciceResetBat ~= "") then
            	self.resetExercice.currentCard:reset()
            	love.system.openURL(folderBaseAddress..liste_revision[currentCard].URLExerciceResetBat)
        	end
		--??need to give the system some time before it run the next sentences ???
			--open in file explorer
			love.system.openURL(self.url)--("file://"..self.url)
			--open the exercice folder in the corresponding software
			if liste_revision[currentCard].URLSoft ~= "" then
				local cmd = liste_revision[currentCard].URLSoft .. ' "' .. self.url .. '"'
				os.execute(cmd)
			end
			-- voir note Obsidian 03.project -> 0x centre formation madhackademy -> centre formation kanban -> ouverture auto 
			--os.execute 'code' ouvre le dossier ou la carte d'exercice directement avec code
			--os.execute('code "'..self.url..'"')
		end

	end)

	self.menuButton.done = Bouton(17,"done",300,150,1,0,
	function ( ... )
		if #liste_revision > 0 then
			stateManager.switch(done)
		end
	end)

	self.menuButton.webGuide = Bouton(28,"webGuide",137,498,1,0,
	function()
		if #liste_revision > 0 then
			local url = liste_revision[currentCard].URLNet
			if url and url ~= "" and url ~= "nil" then
				love.system.openURL(url)
			end
		end
	end)

	self.menuButton.options = Bouton(29,"options",55,55,0.12,0,
	function()
		if self.optionsMenuOpen then
			self:closeOptionsMenu()
		else
			self:openOptionsMenu()
		end
	end)

	self.menuButton.deckInstaller = Bouton(18,"explore deck",300,150,1,0,
	function ( ... )
		stateManager.push(deckInstaller)
	end)
	--[[ ((SOMEWHERE IN OBSIDIAN SHOULD BE A NOTE ABOUT THIS))
	-- self.menuButton.exploreDeck = Bouton(18,"explore deck",300,150,1,0,
	-- function ( ... )
	-- 	stateManager.switch(cardModifier)
	-- end)
	]]
--[[--------------------------------------------------------------------------------------------------------
-- DISABLE ARROW IF NO CONTENT IN TABLE
--]]--
	if #liste_revision < 1 then 
		self.menuButton.arrowLeft.enable = false
		self.menuButton.arrowRight.enable = false
	else
		self.menuButton.arrowLeft.enable = true
		self.menuButton.arrowRight.enable = true
	end
	if #liste_revision > 0 then
		image = love.graphics.newImage(liste_revision[currentCard].URLImage)
	end

	self:applyUpdateCheckState()
	updateCheck.setOnComplete(function()
		currentProjectMenu:applyUpdateCheckState()
	end)
end

function currentProjectMenu:mousepressed(x,y,button)
	if self.optionsMenuOpen and self.optionsMenuButtons then
		for _, menuButton in pairs(self.optionsMenuButtons) do
			menuButton:mousepressed(x, y, button)
		end
	end

	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end

	if self.optionsMenuOpen and button == 1 and not self:isPointOnOptionsMenu(x, y) then
		self:closeOptionsMenu()
	end
end

function currentProjectMenu:mousereleased(x,y,button)
	if self.optionsMenuOpen and self.optionsMenuButtons then
		for _, menuButton in pairs(self.optionsMenuButtons) do
			menuButton:mousereleased(x, y, button)
		end
	end

	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end

function currentProjectMenu:keypressed(key)
	if key == "i" then 
		print(currentCard)
	end
end


function currentProjectMenu:update(dt)

	for key,button in pairs(self.menuButton) do
		button:update(dt)
	end

	if self.updateAvailable then
		self.optionsHaloPhase = (self.optionsHaloPhase or 0) + dt
	end

	self:updateOptionsMenuButtons(dt)

end

function currentProjectMenu:leave()
	updateCheck.clearOnComplete()
end

function currentProjectMenu:draw()

	local drawOrder = {"start", "done", "webGuide", "newCard", "deckInstaller", "arrowLeft", "arrowRight"}
	for _, key in ipairs(drawOrder) do
		local button = self.menuButton[key]
		if button then
			button:draw()
		end
	end

	if self.updateAvailable and self.menuButton.options then
		drawOptionsUpdateHalo(self.menuButton.options, self.optionsHaloPhase)
	end
	if self.menuButton.options then
		self.menuButton.options:draw()
	end

	self:drawOptionsMenu()
		--love.graphics.setColor(255,255,255)
		love.graphics.printf(v_printf,0,0,largeur,"center")
		if image ~= nil then
			love.graphics.draw(image,350,165)
		end
		if #liste_revision > 0 then
			love.graphics.printf(c_printf,0,100,largeur, "center")
		end
end




return currentProjectMenu
