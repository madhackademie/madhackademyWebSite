# Lance FlashRevisionSoft (Love2D) — lovec.exe = fenetre console noire (prints updateCheck)
$LoveExe = "C:\Program Files\LOVE\lovec.exe"
$GameDir = Join-Path $PSScriptRoot "..\SquelletteGCS" | Resolve-Path

if (-not (Test-Path $LoveExe)) {
    Write-Error "Love2D introuvable: $LoveExe (winget install LOVE.LOVE)"
    exit 1
}

Start-Process -FilePath $LoveExe -ArgumentList $GameDir -WorkingDirectory $GameDir
