emptyState = {}

function emptyState:enter(oldstate)
    self.oldstate = oldstate
    
--[[--------------------------------------------------------------------------------------------------------
-- BUTTON TABLE
--]]--

    --self.menuButton = {}
	-- self.menuButton.back = Bouton(25,"back",largeur/6,hauteur - 60 ,1,0,
    -- function()
    -- stateManager.pop()
    -- end)
     
end

function emptyState:mousepressed(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end
end

function emptyState:mousereleased(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end

function emptyState:update( dt )
    for k,button in pairs (self.menuButton) do
        button:update(dt)
    end
	for key,box in pairs(self.menuTextBox) do
		box:update(dt)
	end
end


function emptyState:draw()
    for k,button in pairs (self.menuButton) do
        button:draw()
    end
    for key,box in pairs(self.menuTextBox) do
		box:draw()
	end
end

return emptyState