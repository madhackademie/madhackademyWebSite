done = {}

function done:enter(oldstate,x,y)
    self.oldstate = oldstate
   
    
--[[--------------------------------------------------------------------------------------------------------
--RESET BAT OBJ 
--]]--
    self.resetExercice = {}
    self.resetExercice.currentCard = ResetExercice(
        folderBaseAddress..liste_revision[currentCard].URLCopy,
        folderBaseAddress..liste_revision[currentCard].URLExercice,
        folderBaseAddress..liste_revision[currentCard].URLExerciceResetBat
    )

--[[--------------------------------------------------------------------------------------------------------
--SWITCH FUNC
--]]--
    function done:switch(Difficulte)
        --reset the Worksheet or exercice sheet
        if(liste_revision[currentCard].URLExerciceResetBat ~= "") then
                --controle du bat avant execution 
                self.resetExercice.currentCard:reset()
                love.system.openURL(folderBaseAddress..liste_revision[currentCard].URLExerciceResetBat)
        end
        --when scoring 4 or 5 then keep increasing the timedelta before instantiate the card again
        if Difficulte > 3 then 
            --relearn 2 day in a row
            if liste_revision[currentCard].nbOccured <= 1 then 
                liste_revision[currentCard].nextRevision = math.floor( os.time() / 86400 + 1 ) * 86400
            end
            --at the 3rd iteration whe will let 4 day before whe instantiate the card again
            if liste_revision[currentCard].nbOccured == 2 then
                liste_revision[currentCard].nextRevision = math.floor( os.time() / 86400 + 4 ) * 86400 
                --need to save the delta for the next occurancy
                liste_revision[currentCard].timeDelta = 4 --interval in day
            end
            if liste_revision[currentCard].nbOccured > 2 then
                --SM2 algo
                --ef
                --liste_revision[currentCard].ef is already the old value before whe do the calculation there is 
                --no need for an efPrime var
                liste_revision[currentCard].ef =  util.clamp(liste_revision[currentCard].ef + 
                (0.1-(5-Difficulte))*(0.08+(5-Difficulte)*0.02),1.3,2.5)--!!Need control debug
                --calculation for timeDelta before next instantiation 
                liste_revision[currentCard].timeDelta = math.floor(liste_revision[currentCard].timeDelta * liste_revision[currentCard].ef)
                local timestamp_jour_precedent = math.floor(os.time() / 86400 + 1 ) * 86400
                liste_revision[currentCard].nextRevision =
                math.floor(timestamp_jour_precedent + liste_revision[currentCard].timeDelta * 86400)--given in second with unix timestamp
                --could be bether because if a given day you start 10 min before the card will not be instantiate :( or will it ?
                --check the kaban polish section in obsidian for more about this
            end
            liste_revision[currentCard].nbOccured = liste_revision[currentCard].nbOccured + 1
        end

        --if hard or no memory reset the card
        if Difficulte < 4 then 
            liste_revision[currentCard].nbOccured = 0
            --keep learning it every day until you score at least 4 
            liste_revision[currentCard].nextRevision = math.floor( os.time() / 86400 + 1 ) * 86400
            
        end
        liste_revision[currentCard].nextTimeDate = (os.date('%d-%m-%Y',liste_revision[currentCard].nextRevision))--!!Need control debug
        --keep stat to know how much time whe instantiate this card
        liste_revision[currentCard].nbOccuredTotal = liste_revision[currentCard].nbOccuredTotal +1 --test control json
        local file =io.open(dataJsonAddress,"w+")--pour ouvrir à partir de la racine dossier courant du main, w pour l'ecriture 
        file:write(json.encode(liste_cartes,{indent=true}))
        file:flush ()
        file:close()
    end


--[[--------------------------------------------------------------------------------------------------------
-- BUTTON TABLE
--]]--

    self.menuButton = {}


    self.menuButton.easy = Bouton(19,"easy",150,150,1,0,
    function ( ... )
        done:switch(5)
        stateManager.switch(menuStream)
    end)
    
    self.menuButton.normal = Bouton(20,"normal",150,150,1,0,
	function ( ... )
        done:switch(4)
    stateManager.switch(menuStream)
    end)
    
    self.menuButton.difficult = Bouton(21,"difficult",150,150,1,0,
	function ( ... )
        done:switch(3)
        stateManager.switch(menuStream)
    end)

    self.menuButton.hard = Bouton(22,"hard",150,150,1,0,
	function ( ... )
        done:switch(2)
        stateManager.switch(menuStream)
    end)

    self.menuButton.noMemory = Bouton(23,"no memory",150,150,1,0,
	function ( ... )
        done:switch(1)
        stateManager.switch(menuStream)
	end)


end

function done:mousepressed(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end
end

function done:mousereleased(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end


function done:update( dt )
    for k,button in pairs (self.menuButton) do
        button:update(dt)
    end
end


function done:draw()

    for k,button in pairs (self.menuButton) do
        button:draw()
    end

end

function done:keypressed(key)

end


return done