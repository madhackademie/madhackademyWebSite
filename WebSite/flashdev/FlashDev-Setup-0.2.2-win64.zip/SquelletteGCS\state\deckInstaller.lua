deckInstaller = {}

function deckInstaller:enter(oldstate,x,y)
    folder_path = nil
    self.newImage = nil

--[[--------------------------------------------------------------------------------------------------------
-- BUTTON TABLE
--]]--
  self.menuButton = {}

  self.menuButton.AddDeck = Bouton(24,"AddDeck",300,150,1,0,
  function()
    selectFolder()
    end)

  self.menuButton.back = Bouton(25,"back",largeur/6,hauteur - 60 ,1,0,
  function()
    stateManager.pop()
  end)

  self.menuButton.install = Bouton(26,"install",350,160,1,0,
  function()
    install()
  end)
  self.menuButton.install.enable = false
  self.menuButton.install.enableFunc = false



--[[[--------------------------------------------------------------------------------------------------------
$$$$ folder picker
--]]--

    function open_directory_picker(initial_folder)
        --!!!!!NEED TO BE RESET TO BLANCK FOLDER THERE AND L.36
        local handle = io.popen([[powershell -command "Add-Type -AssemblyName System.Windows.Forms; $fbd = New-Object System.Windows.Forms.FolderBrowserDialog;$fbd.SelectedPath = ']] .. initial_folder .. [['; if ($fbd.ShowDialog() -eq 'OK') { $fbd.SelectedPath }"]])
        local result = handle:read("*a")
        handle:close()
        return result:gsub("\n", "")
    end

    --save folder path
    function selectFolder()
        local deck_path = open_directory_picker("C:\\Users\\madbox\\OneDrive\\RevisionSoft\\DeckTest")--!!!!NEED TO BE RESET TO BLANCK FOLDER AS WELL AS L.28
        if deck_path and deck_path ~= "" then
            folder_path = deck_path
            has_deck_installer()
            -- maintenant tu peux : lire deck.json, install_paths.json, etc.
        else
            local message = "Aucun   dossier   sélectionné ."
            stateManager.push(feedBackPrint,message)
        end
    end

    --control if the folder selected is a valid deck folder 
    function has_deck_installer()
        --[[ draw the deck image and ask if the user want to install the deck
            1. need to xcopy the DeckImage.png in a imagefolder created for this purpose only
            then only whe will be able to draw the DeckImage on screen.
            2.add a btn to confirm the installation (install) but setActive only when alle the check are ok
                1. DeckInstaller.json at true
                2. DeckImage.png at true
        ]]
        local file_path = folder_path .. "/DeckInstaller.json"
        local f = io.open(file_path, "r")
        if f then
            f:close()
            --intégration de l'image du deck
            local deckSrcImage = folder_path.."\\deckImageFolder\\DeckImage.png"
            --ouverture en read binary
            local file = assert(io.open(deckSrcImage,"rb"))
            --lecture et affectation de l'intégralité du fichier
            local data = file:read("*all")
            --fermeture du fichier apres lecture et stokage
            file:close()
            --créer un objet FileData en mémoire
            local newFile = love.filesystem.newFileData(data,"DeckImage.png")
            self.newImage = love.graphics.newImage(newFile)
            --local deckDstImage = folderBaseAddress.."images_current\\deckTempImage" 
            --copy_dir_windows(deckSrcImage, deckDstImage)
            self.menuButton.install.enable = true
            self.menuButton.install.enableFunc = true
            return true
        else
            local message = "this  is  not  the  folder  you  are  looking  for...."
            stateManager.push(feedBackPrint,message)
            return false
        end
    end

    function install()
        local srcExercice = folder_path .. "\\ExerciceFolder"
        local dstExercice = folderBaseAddress .. "elements_revisions"
        copy_dir_windows(srcExercice, dstExercice)

        local srcImage = folder_path .. "\\ImageFolder"
        local dstImage = folderBaseAddress .. "images_current"
        copy_dir_windows(srcImage, dstImage)

        updateJson(folder_path .. "/DeckInstaller.json")
    end

    function copy_dir_windows(src, dst)
        if not src or src == "" or not dst or dst == "" then
            stateManager.push(feedBackPrint, "corrupted  file  or  no  data .")
            print("corrupted file or no data")
            return
        end

        local command = 'xcopy "' .. src .. '" "' .. dst .. '" /E /I /Y'
        print("Running:", command)
        runCommand(command)
    end

    function runCommand(cmd)
        local handle = io.popen("cmd /C " .. cmd)
        if handle then
            local result = handle:read("*a")
            handle:close()
            print("\27[31mCommande executee:\27[0m\n", cmd)
            print("\27[36mResultat:\27[0m\n" .. result)
        end
    end

    --[[JSON UPDATE]]
    function updateJson(jsonPath)
        local newCards = util.loadJson(jsonPath)
        if not newCards then
            print("Erreur : impossible de lire le deck JSON.")
            return
        end

        local daySeconds = 86400
        local intervalDays = 1
        local today = math.floor(os.time() / daySeconds)
        local nextId = #liste_cartes + 1

        for i = 1, #newCards do
            local card = newCards[i]
            local unlockDay = today + (i - 1) * intervalDays
            card.nextRevision = unlockDay * daySeconds
            card.nextTimeDate = os.date('%d-%m-%Y', card.nextRevision)
            card.id = nextId
            nextId = nextId + 1
            table.insert(liste_cartes, card)
        end

        local file = io.open(dataJsonAddress, "w")
        if file then
            file:write(json.encode(liste_cartes, { indent = true }))
            file:close()
        else
            print("Erreur : impossible d'écrire data.json.")
            return
        end

        stateManager.push(feedBackPrint, "install  complet  thx  for  the  money .", imageFeedBack)
    end
end

function deckInstaller:mousepressed(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end
end

function deckInstaller:mousereleased(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end

function deckInstaller:update( dt )
    for k,button in pairs (self.menuButton) do
        button:update(dt)
    end
end

function deckInstaller:draw()

    for k,button in pairs (self.menuButton) do
        button:draw()
    end
    if self.newImage ~= nil then 
        love.graphics.draw(self.newImage,250,225)
    end
end

return deckInstaller