-- UPDATE_TEST v0.2.1 — marqueur release (doit apparaitre apres mise a jour 1 clic)
-- Cette ligne permet d'afficher des traces dans la console pendant l'éxécution
io.stdout:setvbuf('no')
math.randomseed(os.time())

--[[--------------------------------------------------------------------------------------------------------
-- VARIABLE ET TABLE
--]]--

copyPast = love.system.getClipboardText()
json = require("json")
objJsonAddress = nil
dataJsonAddress = nil
folderBaseAddress = nil
liste_cartes = {}
liste_revision = {}
currentCard = 1
liste_object = {}
imageFeedBack = love.graphics.newImage("/images_current/FeedBackImg.jpg")
largeur,hauteur = love.graphics.getDimensions()
font = love.graphics.newFont("BEBAS__.ttf", 24)
love.graphics.setFont(font)
Class = require("lib/class")
Image = require("lib/class/image")
Bouton = require("lib/class/button")
Textbox = require("lib/class/textBox")
ResetExercice = require("lib/class/resetExercice")
utf8 = require("utf8")
util = require("util")
updateCheck = require("lib/updateCheck")
stateManager = require("lib/gamestate")
-----state----
menuStream = require("state/menuStream")
currentProjectMenu = require("state/currentProjectMenu")
addNewCard = require("state/addNewCard")
deckInstaller = require("state/deckInstaller")
feedBackPrint = require("state/feedBackPrint")
--cardModifier = require("state/cardModifier")
done = require("state/done")



-------------------------------------------GENERAL LOAD/UPDATE/DRAW----------------------------------------
function love.load()
	
	----------------------------------------------------------------
	folderBaseAddress = util.resolveBasePath()
	objJsonAddress = folderBaseAddress .. "lib/class/liste_object.json"
	dataJsonAddress = folderBaseAddress .. "data.json"

--[[--------------------------------------------------------------------------------------------------------
ICI JSON POSITION OBJECT
--]]--
	liste_object = util.loadJson("lib/class/liste_object.json")

	updateCheck.startAsyncCheck(folderBaseAddress)

	stateManager.switch(menuStream)
 
end

function love.update(dt)

	updateCheck.poll()
	stateManager.update(dt)

end

function love.draw()

	stateManager.draw()
	
end

function love.mousepressed(x,y,button)
	stateManager.mousepressed(x,y,button)
end

function love.mousereleased(x,y,button)
	stateManager.mousereleased(x,y,button)
end


function love.keypressed(key)
	stateManager.keypressed(key)
	if key == "escape" then
		love.event.push("quit")
	end
end

function love.textinput (text)
	stateManager.textinput(text)
    if Textbox.enable == true then
        Textbox.text = Textbox.text .. text
    end
end

-- function love.keypressed(key)
    -- if key == "backspace" then
    --     -- get the byte offset to the last UTF-8 character in the string.
    --     local byteoffset = utf8.offset(text, -1)
 
    --     if byteoffset then
    --         -- remove the last UTF-8 character.
    --         -- string.sub operates on bytes rather than UTF-8 characters, so we couldn't do string.sub(text, 1, -2).
    --         text = string.sub(text, 1, byteoffset - 1)
    --     end
    -- end
-- end

