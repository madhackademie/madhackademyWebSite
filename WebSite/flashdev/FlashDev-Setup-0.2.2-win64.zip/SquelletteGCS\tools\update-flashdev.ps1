#Requires -Version 5.1
<#
.SYNOPSIS
    Telecharge et installe une mise a jour FlashDev (code app uniquement).

.DESCRIPTION
    Phase B - preserve data.json, elements_revisions, images user, liste_object.json.
    Lance depuis le menu Options (Love2D se ferme avant l'execution).

.PARAMETER InstallDir
    Dossier SquelletteGCS (contient data.json).

.PARAMETER DownloadUrl
    URL du zip release (absolue ou relative au site).

.PARAMETER ExpectedSha256
    Hash SHA-256 attendu (hex). Si vide, verification ignoree avec avertissement.

.EXAMPLE
    .\update-flashdev.ps1 -InstallDir "C:\FlashDev\SquelletteGCS" `
        -DownloadUrl "https://gameopenmoney.com/flashdev/FlashRevisionSoft-0.2.0-win64.zip" `
        -ExpectedSha256 "abc123..."
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$InstallDir,

    [Parameter(Mandatory = $false)]
    [string]$DownloadUrl = "",

    [string]$ExpectedSha256 = "",

    [string]$PackagePath = "",

    [string]$ManifestUrl = "https://gameopenmoney.com/flashdev/latest-version.json",

    [switch]$NoRelaunch,

    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$script:LogLines = @()

function Write-Log {
    param([string]$Message)
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    $script:LogLines += $line
    Write-Host $line
}

function Resolve-DownloadUrl {
    param([string]$Url)
    if ($Url -match '^https?://') {
        return $Url
    }
    if ($Url.StartsWith('/')) {
        return "https://gameopenmoney.com$Url"
    }
    return $Url
}

function Get-StagingRoot {
    param([string]$StagingDir)
    $direct = Join-Path $StagingDir "main.lua"
    if (Test-Path $direct) {
        return $StagingDir
    }
    $nested = Join-Path $StagingDir "SquelletteGCS\main.lua"
    if (Test-Path $nested) {
        return Join-Path $StagingDir "SquelletteGCS"
    }
    throw "Archive invalide : main.lua introuvable a la racine du zip."
}

function Test-ShouldPreserveUserFile {
    param([string]$RelativePath)

    $rel = ($RelativePath -replace '\\', '/').TrimStart('./')
    $rel = $rel.ToLowerInvariant()

    $preserveExact = @(
        'data.json',
        'databackup.json',
        'data1.json',
        'data_old_flashcard.json',
        'lib/class/liste_object.json'
    )
    if ($preserveExact -contains $rel) {
        return $true
    }
    if ($rel -eq 'elements_revisions' -or $rel.StartsWith('elements_revisions/')) {
        return $true
    }
    if ($rel -eq 'images_current' -or $rel.StartsWith('images_current/')) {
        if ($rel -eq 'images_current/buton_choix-assets' -or $rel.StartsWith('images_current/buton_choix-assets/')) {
            return $false
        }
        return $true
    }
    if ($rel -eq 'update_work' -or $rel.StartsWith('update_work/')) {
        return $true
    }
    if ($rel -eq 'tools/update.log' -or $rel.StartsWith('tools/update')) {
        return $true
    }
    return $false
}

function Backup-UserData {
    param(
        [string]$Root,
        [string]$BackupDir
    )

    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null

    $files = @(
        'data.json',
        'DataBackup.json',
        'lib\class\liste_object.json'
    )
    foreach ($name in $files) {
        $src = Join-Path $Root $name
        if (Test-Path $src) {
            $dst = Join-Path $BackupDir $name
            $parent = Split-Path $dst -Parent
            if (-not (Test-Path $parent)) {
                New-Item -ItemType Directory -Path $parent -Force | Out-Null
            }
            Copy-Item -Path $src -Destination $dst -Force
            Write-Log "Backup: $name"
        }
    }
}

function Copy-AppFromStaging {
    param(
        [string]$StagingRoot,
        [string]$InstallRoot
    )

    $files = Get-ChildItem -Path $StagingRoot -Recurse -File
    $copied = 0
    $skipped = 0

    foreach ($file in $files) {
        $relative = $file.FullName.Substring($StagingRoot.Length).TrimStart('\', '/')
        if (Test-ShouldPreserveUserFile -RelativePath $relative) {
            $skipped++
            continue
        }

        $dest = Join-Path $InstallRoot $relative
        $destParent = Split-Path $dest -Parent
        if (-not (Test-Path $destParent)) {
            New-Item -ItemType Directory -Path $destParent -Force | Out-Null
        }

        if ($WhatIf) {
            Write-Log "[WhatIf] Copie: $relative"
        }
        else {
            Copy-Item -Path $file.FullName -Destination $dest -Force
        }
        $copied++
    }

    Write-Log "Fichiers copies: $copied | preserves (user): $skipped"
}

function Find-LoveExecutable {
    $candidates = @(
        "${env:ProgramFiles}\LOVE\love.exe",
        "${env:ProgramFiles}\LOVE\lovec.exe",
        "${env:ProgramFiles(x86)}\LOVE\love.exe"
    )
    foreach ($path in $candidates) {
        if (Test-Path $path) {
            return $path
        }
    }
    return $null
}

# --- Main ---

$InstallDir = (Resolve-Path -LiteralPath $InstallDir).Path
if (-not $PackagePath) {
    if (-not $DownloadUrl) {
        throw "DownloadUrl ou PackagePath requis."
    }
    $DownloadUrl = Resolve-DownloadUrl -Url $DownloadUrl
}

if (-not (Test-Path (Join-Path $InstallDir "data.json"))) {
    throw "InstallDir invalide (data.json introuvable): $InstallDir"
}

$workRoot = Join-Path $InstallDir "update_work"
$backupRoot = Join-Path $workRoot ("backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
$stagingRoot = Join-Path $workRoot "staging"
$zipPath = Join-Path $workRoot "package.zip"
$logPath = Join-Path $InstallDir "tools\update.log"

Write-Log "FlashDev update - InstallDir: $InstallDir"
if ($PackagePath) {
    Write-Log "Mode: package local"
} else {
    Write-Log "Download: $DownloadUrl"
}

New-Item -ItemType Directory -Path $workRoot -Force | Out-Null
New-Item -ItemType Directory -Path (Split-Path $logPath -Parent) -Force | Out-Null

try {
    Backup-UserData -Root $InstallDir -BackupDir $backupRoot

    if ($PackagePath) {
        $PackagePath = (Resolve-Path -LiteralPath $PackagePath).Path
        Write-Log "Package local: $PackagePath"
        if (-not $WhatIf) {
            Copy-Item -Path $PackagePath -Destination $zipPath -Force
        }
    }
    else {
        Write-Log "Telechargement..."
        if ($WhatIf) {
            Write-Log "[WhatIf] Invoke-WebRequest -> $zipPath"
        }
        else {
            $ProgressPreference = 'SilentlyContinue'
            Invoke-WebRequest -Uri $DownloadUrl -OutFile $zipPath -UseBasicParsing
        }
    }

    if (-not $WhatIf) {
        if (-not (Test-Path $zipPath)) {
            throw "Telechargement echoue (fichier absent)."
        }

        $hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
        Write-Log "SHA-256 telecharge: $hash"

        $expected = ($ExpectedSha256 -replace '\s', '').ToLowerInvariant()
        if ($expected -and $expected -ne '') {
            if ($hash -ne $expected) {
                throw "SHA-256 invalide. Attendu: $expected | Obtenu: $hash"
            }
            Write-Log "SHA-256 OK"
        }
        else {
            Write-Log "ATTENTION: sha256 non fourni - verification d'integrite ignoree."
        }
    }

    if (Test-Path $stagingRoot) {
        Remove-Item -Path $stagingRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null

    Write-Log "Extraction..."
    if ($WhatIf) {
        Write-Log "[WhatIf] Expand-Archive -> $stagingRoot"
    }
    else {
        Expand-Archive -Path $zipPath -DestinationPath $stagingRoot -Force
    }

    $appRoot = if ($WhatIf) { $stagingRoot } else { Get-StagingRoot -StagingDir $stagingRoot }

    Write-Log "Copie code app (whitelist implicite - preserve user data)..."
    Copy-AppFromStaging -StagingRoot $appRoot -InstallRoot $InstallDir

    Write-Log "Mise a jour terminee."

    if (-not $NoRelaunch -and -not $WhatIf) {
        $love = Find-LoveExecutable
        if ($love) {
            Write-Log "Relance Love2D: $love"
            Start-Process -FilePath $love -ArgumentList "`"$InstallDir`"" -WorkingDirectory $InstallDir
        }
        else {
            Write-Log "Love2D introuvable - relance manuelle depuis $InstallDir"
        }
    }
}
catch {
    Write-Log "ERREUR: $($_.Exception.Message)"
    Write-Log "Backup disponible: $backupRoot"
    throw
}
finally {
    $script:LogLines | Set-Content -Path $logPath -Encoding UTF8
}
