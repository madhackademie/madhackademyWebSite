#Requires -Version 5.1
<#
.SYNOPSIS
    Installe le socle FlashDev : LÖVE 11.x, VS Code, extensions Lua, raccourci Bureau.

.DESCRIPTION
    Cible les eleves / utilisateurs finaux. N installe pas Raylib (deck C++ = etape separee).

.EXAMPLE
    .\scripts\install-madhackademy.ps1

.EXAMPLE
    .\scripts\install-madhackademy.ps1 -DryRun

.EXAMPLE
    .\scripts\install-madhackademy.ps1 -VerifyOnly
#>

[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$VerifyOnly,
    [switch]$SkipLove,
    [switch]$SkipVSCode,
    [switch]$SkipExtensions,
    [switch]$NoDesktopShortcut,
    [string]$LoveExe = "C:\Program Files\LOVE\love.exe",
    [string]$LoveConsoleExe = "C:\Program Files\LOVE\lovec.exe"
)

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $PSCommandPath
$repoRoot = Split-Path -Parent $scriptDir
$gameDir = Join-Path $repoRoot "SquelletteGCS"
$mainLua = Join-Path $gameDir "main.lua"

$LoveWingetId = "LOVE.LOVE"
$VSCodeWingetId = "Microsoft.VisualStudioCode"
$LuaExtensions = @(
    "sumneko.lua",
    "tomblind.local-lua-debugger-vscode"
)

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[!!] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "[KO] $Message" -ForegroundColor Red
}

function Test-WingetAvailable {
    return [bool](Get-Command winget -ErrorAction SilentlyContinue)
}

function Get-VSCodeBinDirs {
    return @(
        (Join-Path $env:LOCALAPPDATA "Programs\Microsoft VS Code\bin"),
        (Join-Path ${env:ProgramFiles} "Microsoft VS Code\bin"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft VS Code\bin")
    ) | Where-Object { $_ -and (Test-Path $_) }
}

function Test-LoveInstalled {
    param([string]$Path = $LoveExe)
    return Test-Path $Path
}

function Test-VSCodeInstalled {
    if (Get-Command code -ErrorAction SilentlyContinue) {
        return $true
    }
    foreach ($dir in Get-VSCodeBinDirs) {
        if (Test-Path (Join-Path $dir "code.cmd")) {
            return $true
        }
    }
    return $false
}

function Ensure-VSCodeInPath {
    if (Get-Command code -ErrorAction SilentlyContinue) {
        return $true
    }

    foreach ($dir in Get-VSCodeBinDirs) {
        $codeCmd = Join-Path $dir "code.cmd"
        if (-not (Test-Path $codeCmd)) {
            continue
        }

        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        if ($userPath -split ';' | Where-Object { $_ -ieq $dir }) {
            $env:Path = "$dir;$env:Path"
            return $true
        }

        if ($DryRun) {
            Write-Warn "DryRun : ajouterait $dir au PATH utilisateur"
            return $true
        }

        $newPath = if ([string]::IsNullOrWhiteSpace($userPath)) { $dir } else { "$userPath;$dir" }
        [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
        $env:Path = "$dir;$env:Path"
        Write-Ok "PATH utilisateur : $dir"
        return $true
    }

    return $false
}

function Install-WingetPackage {
    param(
        [string]$Id,
        [string]$Label
    )

    if (-not (Test-WingetAvailable)) {
        throw "winget introuvable. Installe App Installer (Microsoft Store) ou suis NOTE_SETUP-UTILISATEUR.md (installation manuelle)."
    }

    if ($DryRun) {
        Write-Warn "DryRun : winget install --id $Id"
        return
    }

    Write-Host "Installation $Label via winget..."
    & winget install --id $Id -e --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -gt 1) {
        throw "winget a echoue pour $Id (code $LASTEXITCODE)"
    }
}

function Test-LuaExtensions {
    if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
        return $false
    }

    $installed = & code --list-extensions 2>$null
    foreach ($ext in $LuaExtensions) {
        if ($installed -notcontains $ext) {
            return $false
        }
    }
    return $true
}

function Install-LuaExtensions {
    if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
        Write-Warn "code indisponible - extensions Lua ignorees"
        return $false
    }

    $allOk = $true
    foreach ($ext in $LuaExtensions) {
        if ($DryRun) {
            Write-Warn "DryRun : code --install-extension $ext"
            continue
        }

        Write-Host "Extension : $ext"
        & code --install-extension $ext --force
        if ($LASTEXITCODE -ne 0) {
        Write-Warn "Echec extension $ext"
            $allOk = $false
        }
    }
    return $allOk
}

function New-FlashDevDesktopShortcut {
  param(
    [string]$TargetLove = $LoveExe,
    [string]$GamePath = $gameDir
  )

  if (-not (Test-Path $TargetLove)) {
    Write-Warn "Raccourci ignore : $TargetLove introuvable"
    return
  }

  $desktop = [Environment]::GetFolderPath("Desktop")
  $shortcutPath = Join-Path $desktop "FlashDev MadHackademy.lnk"

  if ($DryRun) {
    Write-Warn "DryRun : raccourci $shortcutPath"
    return
  }

  $wsh = New-Object -ComObject WScript.Shell
  $shortcut = $wsh.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = $TargetLove
  $shortcut.Arguments = "`"$GamePath`""
  $shortcut.WorkingDirectory = $GamePath
  $shortcut.Description = "FlashDev - revisions MadHackademy"
  $shortcut.Save()
  Write-Ok "Raccourci Bureau : FlashDev MadHackademy"
}

function Invoke-VerifyReport {
    $results = [ordered]@{}

    $results["LÖVE"] = Test-LoveInstalled
    $results["VS Code (code)"] = Test-VSCodeInstalled -and (Get-Command code -ErrorAction SilentlyContinue)
    $results["Extensions Lua"] = Test-LuaExtensions
    $results["FlashDev (main.lua)"] = Test-Path $mainLua

    Write-Step "Rapport de verification"
    Write-Host "Dossier jeu : $gameDir"
    Write-Host ""

    $allOk = $true
    foreach ($entry in $results.GetEnumerator()) {
        if ($entry.Value) {
            Write-Ok $entry.Key
        }
        else {
            Write-Fail $entry.Key
            $allOk = $false
        }
    }

    if (-not $allOk) {
        Write-Host ""
        Write-Warn "Des elements manquent. Relance install-madhackademy.ps1 ou voir scripts/NOTE_SETUP-UTILISATEUR.md"
        return 1
    }

    Write-Host ""
    Write-Ok "Environnement pret pour FlashDev."
    return 0
}

# --- Main ---

Write-Host ""
Write-Host "FlashDev MadHackademy - installation socle" -ForegroundColor White
Write-Host "Repo : $repoRoot"

if ($VerifyOnly) {
    exit (Invoke-VerifyReport)
}

if (-not (Test-Path $mainLua)) {
    throw "FlashDev introuvable : $mainLua (decompresse ou clone FlashRevisionSoft avant installation)"
}

# LÖVE
if (-not $SkipLove) {
    Write-Step "LÖVE 11.x"
    if (Test-LoveInstalled) {
        Write-Ok "Deja installe : $LoveExe"
    }
    elseif ($DryRun) {
        Write-Warn "DryRun : installerait LÖVE"
    }
    else {
        Install-WingetPackage -Id $LoveWingetId -Label "LÖVE"
        if (-not (Test-LoveInstalled)) {
            Write-Warn "love.exe pas encore visible - redemarre le terminal si besoin"
        }
    }
}

# VS Code
if (-not $SkipVSCode) {
    Write-Step "Visual Studio Code"
    if (Test-VSCodeInstalled) {
        Write-Ok "VS Code detecte"
    }
    elseif ($DryRun) {
        Write-Warn "DryRun : installerait VS Code"
    }
    else {
        Install-WingetPackage -Id $VSCodeWingetId -Label "VS Code"
    }

    if (Ensure-VSCodeInPath) {
        Write-Ok "Commande code disponible"
    }
    else {
        Write-Warn 'code introuvable - reinstalle VS Code en cochant Ajouter au PATH'
    }
}

# Extensions Lua
if (-not $SkipExtensions) {
    Write-Step "Extensions VS Code (Lua / Love2D)"
    if (Test-LuaExtensions) {
        Write-Ok "Extensions Lua deja installees"
    }
    else {
        Install-LuaExtensions | Out-Null
    }
}

# Raccourci Bureau
if (-not $NoDesktopShortcut) {
    Write-Step "Raccourci Bureau"
    New-FlashDevDesktopShortcut
}

exit (Invoke-VerifyReport)
