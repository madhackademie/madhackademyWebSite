local Image = Class{}


function Image:init(pId,pNomImage,pX,pY,pScale,pRotate) --init = constructeur
	self.id = pId
	if liste_object and #liste_object >= self.id then 
		self.x = liste_object[self.id].x
		-- print(liste_object[self.id].x)
		self.y = liste_object[self.id].y
	else 
		self.x = pX 
		self.y = pY 
	end
	self.scale = pScale
	self.rotate = pRotate or 0 
	self.color={255/255,255/255,255/255,255/255}
	self.imageBase = love.graphics.newImage("/images_current/buton_Choix-assets/"..pNomImage..".png")
	self.largeur = self.imageBase:getWidth()*self.scale or self.imageSurv:getWidht()*self.scale
	self.hauteur = self.imageBase:getHeight()*self.scale or self.imageSurv:getHeight()*self.scale
	local p = {}
	p.id = self.id
	p.x = math.floor( self.x )
	p.y = math.floor(self.y)
	local control = false
	for i=1,#liste_object do 
		if liste_object[i].id == self.id then 
			control = true 
		end
	end
	if control == false then 
		table.insert(liste_object,p )
		print(#liste_object)
	end
	local file =io.open(objJsonAddress,"w+")--pour ouvrir à partir de la racine dossier courant du main, w pour l'ecriture 
	file:write(json.encode(liste_object,{indent=true}))
	file:flush ()
	file:close()
end


function Image:draw()
    love.graphics.setColor(self.color)
    --self.color={255/255,255/255,255/255,255/255}--new version love2d color = 0 à 1 donc diviser les couleurs par 255 
    love.graphics.draw(self.imageBase,self.x,self.y,math.rad(self.rotate),self.scale,self.scale,self.imageBase:getWidth()/2,self.imageBase:getHeight()/2)
	love.graphics.setColor(255/255,255/255,255/255,255/255)
end

return Image