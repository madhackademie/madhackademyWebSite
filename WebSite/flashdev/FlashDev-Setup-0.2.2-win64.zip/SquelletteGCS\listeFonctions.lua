--table des fonctions 


--LIGNE POUR INITIALISER L APPEL A METHODE MATH.RANDOM--
math.randomseed(love.timer.getTime())
--selon anata
math.randomseed(os.time())



--DISTANCE ENTRE 2 POINTS-----
function math.dist(x1,y1, x2,y2) return ((x2-x1)^2+(y2-y1)^2)^0.5 end 



-----ANGLE ENTRE 2 "OBJETS"-------
--initilisation en debut de code--
function math.angle(x1,y1, x2,y2) return math.atan2(y2-y1, x2-x1) end
--exemple d'utilisation--
        if liste_aliens[n].type == 3 then 
          if liste_aliens[n].chronotir <= 0 then
            local angle 
            angle = math.angle(liste_aliens[n].x,liste_aliens[n].y,heros.x,heros.y)
            CreeTir("laser2",liste_aliens[n].x,liste_aliens[n].y + liste_aliens[n].image:getHeight(),0,2,2,true,500*math.cos(angle),500*math.sin(angle))
            liste_aliens[n].chronotir = math.random(20,40)
          end
        end
        

local sprite1 = {}
local sprite2 = {}
local liste_sprites = {}

function collide(a1, a2)
 if (a1==a2) then return false end
 local dx = a1.x - a2.x
 local dy = a1.y - a2.y
 if (math.abs(dx) < a1.image:getWidth()+a2.image:getWidth()) then
  if (math.abs(dy) < a1.image:getHeight()+a2.image:getHeight()) then
   return true
  end
 end
 return false
end

function CreeSprite(pNomImage, pX, pY)
  
  sprite = {}
  sprite.x = pX
  sprite.y = pY
  sprite.supprime = false
  sprite.image = love.graphics.newImage("images/"..pNomImage..".png")
  sprite.l = sprite.image:getWidth()
  sprite.h = sprite.image:getHeight()
  
  table.insert(liste_sprites, sprite)
  
  return sprite
  
end

function love.load()
  
  love.window.setMode(1024,768)
  love.window.setTitle("Test collision")
  
  largeur = love.graphics.getWidth()
  hauteur = love.graphics.getHeight()
  
  sprite1 = CreeSprite("heros", largeur/2, hauteur/2)
  sprite1.x = largeur/2
  sprite1.y = largeur/2 
    
  sprite2 = CreeSprite("enemy1", largeur/2, hauteur/2)
  sprite2.x = largeur/2
  sprite2.y = largeur/2 

end

function love.update(dt)
  
  if love.keyboard.isDown("right") then
    sprite1.x = sprite1.x + 4
  end

  if love.keyboard.isDown("left") then
    sprite1.x = sprite1.x - 4
  end
  
  if love.keyboard.isDown("up") then
    sprite1.y = sprite1.y - 4
  end

  if love.keyboard.isDown("down") then
    sprite1.y = sprite1.y + 4
  end

end

function love.draw()
  
  local n
  for n=1,#liste_sprites do
    local s = liste_sprites[n]
    love.graphics.draw(s.image, s.x, s.y, 0, 2, 2, s.l/2, s.h/2)
  end
  
  if collide(sprite1,sprite2) then
    love.graphics.print("Collision")
  end
   
end

function love.keypressed(key)
  
end
  
  
function print_r ( t )  
    local print_r_cache={}
    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                for pos,val in pairs(t) do
                    if (type(val)=="table") then
                        print(indent.."["..pos.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                        print(indent..string.rep(" ",string.len(pos)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."["..pos..'] => "'..val..'"')
                    else
                        print(indent.."["..pos.."] => "..tostring(val))
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end
    if (type(t)=="table") then
        print(tostring(t).." {")
        sub_print_r(t,"  ")
        print("}")
    else
        sub_print_r(t,"  ")
    end
    print()
end


  