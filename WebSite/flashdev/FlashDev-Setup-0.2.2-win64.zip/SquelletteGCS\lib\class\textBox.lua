
local Textbox = Class{}

function Textbox:init(pWidth,pHeight,pX,pY,pCallback,pArgs) --init = constructeur
	self.x = pX
	self.y = pY
    self.text = ''
	self.callback = pCallback
	self.args = pArgs
	self.color={255/255,255/255,255/255,255/255}
	self.backgroundColor = {255/255,255/255,255/255,255/255}
	self.textColor = {40/255,40/255,40/255,255/255}
	self.enable = false
	self.enableFunc = true
	--self.vaisseau = nil
	-- self.imageBase = love.graphics.newImage("images_current/"..pNomImage..".png")
	-- self.imageSurv = love.graphics.newImage("images_current/"..pNomImage.." Surv.png")
	self.largeur = pWidth
	self.hauteur = pHeight
end


function Textbox:mousepressed(x,y,button)
	if self.enableFunc then
		if self.surv then
			if button == 1 then
				if self.callback then -- verification si fonction liee à l'objet
					if self.args then -- et si cette dernière recoit des arguments en parametre
						self.callback(unpack(self.args)) --alors traitement de la fonction avec arg
					else
						self.callback()
					end
				end
			end
		end
	end
end


-- function love.textinput (text)
--     if Textbox.enable then
--         Textbox.text = Textbox.text .. text
--     end
-- end

function Textbox:update(dt)
	mouseX = love.mouse:getX()
	mouseY = love.mouse:getY()
	--if self.enable then
		if mouseX >= self.x  and mouseX <= self.x + self.largeur then
			if mouseY >= self.y and mouseY <= self.y + self.hauteur then
				self.surv=true
				self.enable=true
			else
				self.surv=false
				self.enable=false
			end
		else
			self.surv=false
			self.enable=false
			-- self.clicable = false
		end  
end


function Textbox:draw()
	love.graphics.setColor(self.color)
		love.graphics.setColor(unpack(self.backgroundColor))
		love.graphics.rectangle('fill',
			self.x, self.y,
			self.largeur, self.hauteur)

		love.graphics.setColor(unpack(self.textColor))
		love.graphics.printf(self.text,
			self.x, self.y,
			self.largeur, 'left',0,0.8,0.8)
	love.graphics.setColor(255/255,255/255,255/255,255/255)

end

return Textbox

