--Class = require("lib/class")

Atelier = Class{}

function Atelier:init(pNom,pNomImage,pScale,pRotate,pNbChaptire,pCallback,pArgs) --init = constructeur
	self.nom = pNom
	self.x = largeur/2--512
	self.y = hauteur/2--384
	self.chapitre = {}
	self.scale = pScale
	self.rotate = pRotate or 0
	self.surv = false--si survolé alors true
	self.callback = pCallback
	self.args = pArgs
	--self.vaisseau = nil
	--self.imageBase = love.graphics.newImage("images/bouton/"..pNomImage..".png")
	--self.imageSurv = love.graphics.newImage("images/bouton/"..pNomImage.."Surv.png")
--	self.largeur = self.imageBase:getWidth()*self.scale or self.imageSurv:getWidht()*self.scale
--	self.hauteur = self.imageBase:getHeight()*self.scale or self.imageSurv:getHeight()*self.scale
end


function Atelier:mousepressed(x,y,button)
	if self.surv then
		if button == 1 then
			if self.callback then
				if self.args then
					self.callback(unpack(self.args))
				else
					self.callback()
				end
			end
		end
	end
end

function Atelier:update(dt)
	mouseX = love.mouse:getX()
	mouseY = love.mouse:getY()
	if mouseX >= self.x - self.largeur/2 and mouseX <= self.x + self.largeur/2 then
		if mouseY >= self.y - self.hauteur/2 and mouseY <= self.y + self.hauteur/2 then
			self.surv=true
		else
			self.surv=false
		end
	else
		self.surv=false
		self.clicable = false
	end  
	
end


function Atelier:draw()
	if self.surv == false then
		love.graphics.draw(self.imageBase,self.x,self.y,math.rad(self.rotate),self.scale,self.scale,self.imageBase:getWidth()/2,self.imageBase:getHeight()/2)
	elseif self.surv == true then
		love.graphics.draw(self.imageSurv,self.x,self.y,math.rad(self.rotate),self.scale,self.scale,self.imageSurv:getWidth()/2,self.imageSurv:getHeight()/2)
	end
	if self.vaisseau then
		self.vaisseau:draw()
	end
end

