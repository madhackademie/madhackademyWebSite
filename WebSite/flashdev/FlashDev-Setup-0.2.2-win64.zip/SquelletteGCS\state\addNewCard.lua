addNewCard = {}

function addNewCard:enter(oldstate,x,y)
	-- self.oldstate = oldstate
--[[--------------------------------------------------------------------------------------------------------
-- 	IMAGE TABLE
--]]--

	self.imageChamps = {}
	self.imageChamps.name = Image(6,"name",36,132,1,0)
	self.imageChamps.URLExercice = Image(7,"UrlExercice",150,150,1,0)
	self.imageChamps.URLNet = Image(8,"urlNet",150,150,1,0)
	self.imageChamps.URLCopy = Image(9,"UrlCopy",150,150,1,0)
	self.imageChamps.Vid = Image(10,"urlVideo",300,150,1,0)
	self.imageChamps.Soft = Image(11,"urlSoft",300,150,1,0)
	self.imageChamps.Image = Image(12,"urlImage",300,150,1,0)
	self.imageChamps.Folder = Image(13,"folder",300,150,1,0)
	self.imageChamps.URLExerciceResetBat = Image(14,"UrlExerciceRst",300,150,1,0)
	self.imageChamps.DeckName = Image(15,"deckName",300,150,1,0)

--[[--------------------------------------------------------------------------------------------------------
-- BUTTON TABLE
--]]--
	self.menuButton = {}

	self.menuButton.Add = Bouton(16,"add",300,150,1,0,
	function ()
		local carte =  {}  
		carte.nom = self.menuTextBox.nomCarte.text or "nil"
		carte.URLExercice = self.menuTextBox.URLExercice.text or "nil"
		carte.URLNet = self.menuTextBox.URLNet.text or "nil"
		carte.URLCopy = self.menuTextBox.URLCopy.text or "nil"--path exercice source
		carte.URLVid = self.menuTextBox.URLVid.text or "nil"
		carte.URLSoft = self.menuTextBox.URLSoft.text or "nil"
		carte.URLImage = self.menuTextBox.URLImage.text or "nil"
		carte.URLFolder = self.menuTextBox.URLFolder.text or "nil"--path dossier flashcard complet
		carte.URLExerciceResetBat = self.menuTextBox.URLExerciceResetBat.text or "nil"--path .bat 
		carte.DeckName = self.menuTextBox.DeckName.text or ""
		carte.id = #liste_cartes + 1
		--carte.ef = 2.5
		carte.dateCreation = os.date()
		carte.lastTime = os.time()
		carte.timeDelta = 0--math.floor((os.time() - carte.lastTime)/86400) + 1
		--carte.Difficulte = 5
		carte.nbOccured = 0
		carte.nbOccuredTotal = 0
		--carte.efPrime = 0
		carte.ef = 0
		carte.nextTimeDate = 0
		carte.nextRevision = 0
		--carte.nextTimeDate = 0
		--carte.URLCopy = ""
		--carte.nextTimeDate = (os.date('%Y-%m-%d %H:%M:%S',carte.nextRevision))
		table.insert( liste_cartes, carte )
		local file =io.open(dataJsonAddress,"w")--pour ouvrir à partir de la racine dossier courant du main, w pour l'ecriture 
        file:write(json.encode(liste_cartes,{indent=true}))
		file:flush ()
		file:close()
		stateManager.pop()
	end)
	self.menuButton.back = Bouton(5,"back",largeur/6,hauteur - 60 ,1,0,		
	function()
		stateManager.pop() 
	end)

--[[--------------------------------------------------------------------------------------------------------
-- TEXTBOX TABLE
--]]--
	self.menuTextBox = {}

	self.menuTextBox.nomCarte = Textbox(1000,30,self.imageChamps.name.x + self.imageChamps.name.largeur/2,self.imageChamps.name.y )--,self.menuButton.newCard.x + self.menuButton.newCard.largeur,0)--self.menuButton.newCard.y)
	self.menuTextBox.URLExercice = Textbox(1000,30,self.imageChamps.URLExercice.x + self.imageChamps.URLExercice.largeur/2,self.imageChamps.URLExercice.y )
	self.menuTextBox.URLNet = Textbox(1000,30,self.imageChamps.URLNet.x + self.imageChamps.URLNet.largeur/2,self.imageChamps.URLNet.y )
	self.menuTextBox.URLCopy = Textbox(1000,30,self.imageChamps.URLCopy.x + self.imageChamps.URLCopy.largeur/2,self.imageChamps.URLCopy.y )
	self.menuTextBox.URLVid = Textbox(1000,30,self.imageChamps.Vid.x + self.imageChamps.Vid.largeur/2,self.imageChamps.Vid.y )
	self.menuTextBox.URLSoft = Textbox(1000,30,self.imageChamps.Soft.x + self.imageChamps.Soft.largeur/2,self.imageChamps.Soft.y )
	self.menuTextBox.URLImage = Textbox(1000,30,self.imageChamps.Image.x + self.imageChamps.Image.largeur/2,self.imageChamps.Image.y )
	self.menuTextBox.URLFolder = Textbox(1000,30,self.imageChamps.Folder.x + self.imageChamps.Folder.largeur/2,self.imageChamps.Folder.y )
	self.menuTextBox.URLExerciceResetBat = Textbox(1000,30,self.imageChamps.URLExerciceResetBat.x + self.imageChamps.URLExerciceResetBat.largeur/2,self.imageChamps.URLExerciceResetBat.y )
	self.menuTextBox.DeckName = Textbox(1000,30,self.imageChamps.DeckName.x + self.imageChamps.DeckName.largeur/2,self.imageChamps.DeckName.y )
	
end

function addNewCard:mousepressed(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousepressed(x,y, button)
	end
end

function addNewCard:mousereleased(x,y,button)
	for k,v in pairs(self.menuButton) do
		v:mousereleased(x,y, button)
	end
end

function addNewCard:textinput (text)
	for k,v in pairs(self.menuTextBox) do
		if v.enable then 
			v.text = v.text..text
			
		end
	end
end-- 

function addNewCard:update( dt )
	
	for k,button in pairs (self.menuButton) do
		button:update(dt)
	end
	for key,box in pairs(self.menuTextBox) do
		box:update(dt)
	end
end


function addNewCard:draw()

	for k,button in pairs (self.menuButton) do
		button:draw()
	end
	for key,image in pairs(self.imageChamps) do
		image:draw()
	end

	for key,box in pairs(self.menuTextBox) do
		box:draw()
	end
--[[--------------------------------------------------------------------------------------------------------
		affichage d'un etat sur un autre etat
		1) possibilité via le oldstate de lire/ecrire les variables du oldstate(etat arriere plan) ATTENTION les variables etat
			doivent etre en .self pour que cela fonctionne
		 //ici mise en pause avec arriere plan inactif et filtre
--]]--
	-- self.oldstate:draw()
	-- love.graphics.setColor(0,0,0,0)
	-- love.graphics.rectangle("fill",0,0,largeur,hauteur)
	-- love.graphics.setColor(255,0,0)
	-- love.graphics.rectangle("fill",200,500,400,500)
	-- love.graphics.setColor(255,255,255)

end

function addNewCard:leave(  )
	--ici les listes pour réinitialiser et controler si les variable sont liée au state ou en globale pov tache
	--exemple menuboutton = {}
end

function addNewCard:keypressed(key)
	for k,v in pairs(self.menuTextBox) do
		if v.enable then 
			if key == "backspace" then
				-- get the byte offset to the last UTF-8 character in the string.
				local byteoffset = utf8.offset(v.text, -1)

				if byteoffset then
					-- remove the last UTF-8 character.
					-- string.sub operates on bytes rather than UTF-8 characters, so we couldn't do string.sub(text, 1, -2).
					self.menuTextBox[k].text = string.sub(v.text, 1, byteoffset - 1)
				end
			end
		end
	end
	if key == "lctrl" then-- and key == "v" then 
		for k,v in pairs(self.menuTextBox) do
			if v.enable then 
				copyPast = love.system.getClipboardText()
				v.text = v.text..copyPast
			end
		end
	end
	-- if key == "up" then
	--     self.oldstate.currentCard = self.oldstate.currentCard + 1
	-- end
end


return addNewCard